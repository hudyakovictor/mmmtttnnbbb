export type TimeState = "before" | "now" | "after";

export type MarkerKind = "evidence" | "nav" | "info";

export type VisualKind =
  | "van"
  | "crack"
  | "tape"
  | "door"
  | "alarm"
  | "sparkle"
  | "lock"
  | "bag"
  | "cup"
  | "board";

export interface MarkerVisual {
  kind: VisualKind;
  scale?: number;
}

export interface Marker {
  id: string;
  /** 0..1 left → right in the source equirectangular image */
  u: number;
  /** 0..1 top → bottom */
  v: number;
  kind: MarkerKind;
  states: TimeState[];
  evidenceId?: string;
  navTo?: string;
  label: string;
  visual?: MarkerVisual;
}

export type Phase = "setup" | "crime" | "escape" | "aftermath";

export interface Evidence {
  id: string;
  title: string;
  observe: string;
  infer: string;
  icon: string;
  node: string;
  state: TimeState;
  key?: boolean;
  phase?: Phase;
}

export interface PanoNode {
  id: string;
  name: string;
  blurb: string;
  image: string;
  u0: number;
  v0: number;
  markers: Marker[];
}

export interface PhaseDef {
  id: Phase;
  label: string;
  desc: string;
}

export interface CaseFile {
  code: string;
  title: string;
  subtitle: string;
  objective: string;
  briefing: string[];
  nodes: PanoNode[];
  evidence: Evidence[];
  phases: PhaseDef[];
  conclusion: string[];
  keys: string[];
}
