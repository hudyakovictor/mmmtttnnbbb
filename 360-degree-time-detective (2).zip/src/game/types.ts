export type TimeId = "before" | "now" | "after";
export type LocationId = "gallery" | "cafe" | "alley";
export type Phase = "boot" | "intro" | "briefing" | "game" | "verdict";

export interface TimeEpoch {
  id: TimeId;
  label: string;
  short: string;
  clock: string;
  day: string;
  caption: string;
  filter: string;
  wash: string;
  rain: boolean;
}

export interface NavLink {
  to: LocationId;
  yaw: number;
  pitch: number;
  label: string;
}

export interface LocationDef {
  id: LocationId;
  name: string;
  short: string;
  subtitle: string;
  panorama: string;
  nav: NavLink[];
}

export interface ClueMoment {
  headline: string;
  body: string;
  photo?: string;
  hidden?: boolean;
  hiddenLabel?: string;
}

export interface Clue {
  id: string;
  title: string;
  location: LocationId;
  locationByTime?: Partial<Record<TimeId, LocationId>>;
  yaw: number;
  pitch: number;
  yawByTime?: Partial<Record<TimeId, number>>;
  pitchByTime?: Partial<Record<TimeId, number>>;
  key: boolean;
  icon: "window" | "camera" | "van" | "oil" | "umbrella" | "clock" | "pass" | "glass" | "door" | "pot";
  moments: Record<TimeId, ClueMoment>;
  thread: string;
}

export interface DeductionQuestion {
  id: string;
  prompt: string;
  hint: string;
  options: { id: string; label: string; correct: boolean }[];
}

export interface ThreadNote {
  id: string;
  title: string;
  need: string[];
  text: string;
}
