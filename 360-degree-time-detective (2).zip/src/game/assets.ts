import gallery from "../../public/panoramas/gallery.jpg?inline";
import cafe from "../../public/panoramas/cafe.jpg?inline";
import alley from "../../public/panoramas/alley.jpg?inline";
import painting from "../../public/evidence/painting.jpg?inline";
import umbrella from "../../public/evidence/umbrella.jpg?inline";
import van from "../../public/evidence/van.jpg?inline";
import pass from "../../public/evidence/pass.jpg?inline";
import windowShot from "../../public/evidence/window.jpg?inline";
import anna from "../../public/portraits/anna.jpg?inline";
import buyer from "../../public/portraits/buyer.jpg?inline";

export const panoramas = {
  gallery,
  cafe,
  alley,
} as const;

export const photos = {
  painting,
  umbrella,
  van,
  pass,
  window: windowShot,
  anna,
  buyer,
} as const;
