import { photos } from "../game/assets";
import { BRIEFING, CASE, VERDICT_TEXT } from "../game/data";

export function BootScreen({ progress }: { progress: number }) {
  return (
    <div className="grain relative flex h-full items-center justify-center bg-[#070605]">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(80,50,20,0.18),transparent_60%)]" />
      <div className="relative w-72 text-center">
        <p className="font-mono text-[10px] uppercase tracking-[0.42em] text-amber-200/60">хроноскоп · mk.iii</p>
        <div className="mt-6 h-px overflow-hidden bg-white/10">
          <div className="h-full bg-amber-300/80 transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
        <p className="mt-3 font-mono text-[10px] tracking-[0.28em] text-white/35">проявка слоёв {progress}%</p>
      </div>
    </div>
  );
}

export function IntroScreen({ onNext }: { onNext: () => void }) {
  return (
    <div className="grain relative flex h-full flex-col items-center justify-center overflow-hidden bg-[#070605] px-6">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,rgba(140,70,30,0.16),transparent_55%)]" />
      <div className="pointer-events-none absolute inset-8 border border-amber-200/10" />
      <p className="animate-[fade-up_0.8s_ease_both] font-mono text-[10px] uppercase tracking-[0.55em] text-amber-200/55">
        архив временных сфер · дело {CASE.number}
      </p>
      <h1 className="mt-5 animate-[fade-up_1s_0.1s_ease_both] font-serif text-6xl font-medium tracking-[0.18em] text-[#f0e2c8] sm:text-8xl">
        ХРОНОСКОП
      </h1>
      <p className="mt-4 max-w-md animate-[fade-up_1s_0.2s_ease_both] text-center font-serif text-xl italic text-amber-100/70">
        Временной 360° детектив
      </p>
      <p className="mt-8 max-w-sm animate-[fade-up_1s_0.3s_ease_both] text-center text-sm leading-relaxed text-white/45">
        Одна улица. Три точки. Три эпохи. Докажите цепочку через то, что не совпадает.
      </p>
      <button
        onClick={onNext}
        className="mt-12 animate-[fade-up_1s_0.4s_ease_both] border border-amber-200/40 bg-amber-200/10 px-8 py-3 font-mono text-[11px] uppercase tracking-[0.32em] text-amber-100 transition hover:bg-amber-200/20"
      >
        открыть дело
      </button>
    </div>
  );
}

export function BriefingScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="grain relative flex h-full items-center justify-center overflow-auto bg-[#14100c] px-4 py-8">
      <div className="paper-sheet paper-ruled relative w-full max-w-3xl p-6 sm:p-10">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.35em] text-[#7a4b2a]">
              секретный архив · хроноскоп
            </p>
            <h2 className="mt-2 font-serif text-4xl text-[#2a2118] sm:text-5xl">Дело {CASE.number}</h2>
            <p className="font-serif text-2xl italic text-[#6b4a2d]">{CASE.title}</p>
          </div>
          <div className="stamp border-2 border-[#8f2d3a] px-3 py-1 font-mono text-[11px] uppercase tracking-[0.2em] text-[#8f2d3a]">
            не для прессы
          </div>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-[200px_1fr]">
          <figure className="rotate-[-2deg]">
            <img src={photos.painting} alt="" className="h-52 w-full object-cover shadow-xl ring-4 ring-[#f3ead8]" />
            <figcaption className="mt-2 text-center font-mono text-[9px] uppercase tracking-widest text-[#6b4a2d]">
              {CASE.artwork}
            </figcaption>
          </figure>
          <div className="space-y-4 text-[15px] leading-7 text-[#2f261c]">
            <p className="font-serif text-xl leading-8">{BRIEFING.lead}</p>
            <p>{BRIEFING.body}</p>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-[#7a4b2a]">
              пропажа зафиксирована {CASE.lostAt}
            </p>
          </div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <PersonCard
            photo={photos.anna}
            name="Анна Волкова"
            role="Куратор галереи"
            note="Открыла зал в 07:04. Пропуск нашёлся не при ней."
          />
          <PersonCard
            photo={photos.buyer}
            name="«Покупатель»"
            role="Не установлен"
            note="Вчера в кафе. Платил наличными. Смотрел на камеру."
          />
        </div>

        <ol className="mt-8 grid gap-3 border-t border-[#2a2118]/10 pt-6 font-mono text-[11px] uppercase tracking-[0.14em] text-[#5c4630] sm:grid-cols-3">
          <li>01 · Оглянитесь. Найдите шов.</li>
          <li>02 · Смахните время: до / сейчас / после.</li>
          <li>03 · Закрепите улику и перейдите стрелкой.</li>
        </ol>

        <button
          onClick={onStart}
          className="mt-8 w-full bg-[#2a2118] py-3.5 font-mono text-[11px] uppercase tracking-[0.34em] text-[#e7d8c0] transition hover:bg-[#3a2d20]"
        >
          начать расследование
        </button>
      </div>
    </div>
  );
}

function PersonCard({
  photo,
  name,
  role,
  note,
}: {
  photo: string;
  name: string;
  role: string;
  note: string;
}) {
  return (
    <div className="flex gap-3 bg-[#2a2118]/5 p-3">
      <img src={photo} alt="" className="h-20 w-16 object-cover ring-2 ring-[#f3ead8]" />
      <div>
        <p className="font-serif text-lg text-[#2a2118]">{name}</p>
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#8f2d3a]">{role}</p>
        <p className="mt-1 text-sm leading-5 text-[#4a3b2c]">{note}</p>
      </div>
    </div>
  );
}

export function VerdictScreen({
  correct,
  total,
  onReplay,
}: {
  correct: number;
  total: number;
  onReplay: () => void;
}) {
  const perfect = correct === total;
  return (
    <div className="grain relative flex h-full items-center justify-center overflow-auto bg-[#070605] px-4 py-8">
      <div className="relative w-full max-w-2xl border border-amber-200/15 bg-black/50 p-6 backdrop-blur-md sm:p-10">
        <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-amber-200/50">реконструкция ночи</p>
        <h2 className="mt-2 font-serif text-4xl text-[#f0e2c8]">{perfect ? "Цепочка закрыта" : "Версия собрана"}</h2>
        <p className="mt-1 font-mono text-xs text-amber-100/50">
          ответов верно: {correct} / {total}
        </p>
        <div className="mt-8 space-y-4">
          {VERDICT_TEXT.map((p, i) => (
            <p key={i} className="flex gap-4 text-sm leading-7 text-white/70">
              <span className="font-mono text-[10px] text-amber-200/60">0{i + 1}</span>
              {p}
            </p>
          ))}
        </div>
        <div className="mt-10 flex flex-wrap gap-3">
          <button
            onClick={onReplay}
            className="border border-amber-200/40 px-6 py-3 font-mono text-[11px] uppercase tracking-[0.28em] text-amber-100 hover:bg-amber-200/10"
          >
            смотреть улицу снова
          </button>
        </div>
      </div>
    </div>
  );
}
