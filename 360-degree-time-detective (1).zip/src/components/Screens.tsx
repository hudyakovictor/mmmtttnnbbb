import type { CaseFile, Phase } from "@/game/types";

const PHASE_ORDER: Phase[] = ["setup", "crime", "escape", "aftermath"];

/* ----------------------------- INTRO ----------------------------- */
export function IntroScreen({
  caseFile,
  onStart,
}: {
  caseFile: CaseFile;
  onStart: () => void;
}) {
  const bg = caseFile.nodes.find((n) => n.id === "gallery")?.image;
  return (
    <div className="relative h-full w-full overflow-hidden">
      {bg && (
        <div
          className="absolute inset-0 scale-110 bg-cover bg-center opacity-40 blur-md"
          style={{ backgroundImage: `url(${bg})` }}
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/80 to-slate-950" />
      <div className="scanlines" />

      <div className="relative flex h-full w-full flex-col items-center justify-center overflow-y-auto px-5 py-10">
        <div className="w-full max-w-2xl text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 backdrop-blur-sm">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-400" />
            <span className="font-mono text-[10px] tracking-[0.3em] text-cyan-300/90">
              TEMPORAL FORENSICS BUREAU · {caseFile.code}
            </span>
          </div>

          <h1 className="text-5xl font-bold leading-none tracking-tight text-white sm:text-7xl">
            <span className="shimmer">ХРОНО</span>
            <span className="text-glow text-cyan-300">ДЕТЕКТИВ</span>
          </h1>
          <p className="mt-3 font-mono text-xs uppercase tracking-[0.35em] text-white/50">
            Временной 360°-детектив
          </p>
          <p className="mt-4 text-base text-white/75 sm:text-lg">{caseFile.subtitle}</p>

          <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed text-white/55">
            {caseFile.briefing[0]} У вас есть{" "}
            <span className="text-cyan-300">Хроноскан</span> — три снимка улицы с разницей в
            сутки. Найдите несоответствия между эпохами и докажите цепочку событий.
          </p>

          {/* onboarding steps */}
          <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {[
              { n: "1", icon: "🔄", t: "Осмотритесь", d: "Вращайте вид и заметьте несоответствие" },
              { n: "2", icon: "⏱️", t: "Смените эпоху", d: "Смахните шкалу: до / сейчас / после" },
              { n: "3", icon: "🔎", t: "Зафиксируйте", d: "Отметьте улику и идите по стрелке" },
            ].map((s) => (
              <div
                key={s.n}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-left backdrop-blur-sm"
              >
                <div className="flex items-center gap-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-cyan-400/20 font-mono text-xs text-cyan-200">
                    {s.n}
                  </span>
                  <span className="text-xl">{s.icon}</span>
                </div>
                <div className="mt-2 text-sm font-semibold text-white">{s.t}</div>
                <div className="mt-0.5 text-xs leading-snug text-white/50">{s.d}</div>
              </div>
            ))}
          </div>

          <button
            onClick={onStart}
            className="group mt-8 inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-cyan-400 to-amber-400 px-8 py-4 text-base font-bold text-slate-950 shadow-[0_0_40px_-8px_rgba(34,211,238,0.6)] transition hover:scale-[1.03] active:scale-100"
          >
            Начать расследование
            <span className="transition group-hover:translate-x-1">→</span>
          </button>

          <div className="mt-5 font-mono text-[10px] tracking-widest text-white/30">
            3 ЭПОХИ · 4 ТОЧКИ УЛИЦЫ · 9 УЛИК · 1 РАСКРЫТАЯ ЦЕПЬ
          </div>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- WIN ----------------------------- */
export function WinScreen({
  caseFile,
  onRestart,
}: {
  caseFile: CaseFile;
  onRestart: () => void;
}) {
  const keys = PHASE_ORDER.map(
    (p) => caseFile.evidence.find((e) => e.key && e.phase === p)!
  );

  return (
    <div className="relative h-full w-full overflow-y-auto">
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-950/40 via-slate-950 to-slate-950" />
      <div className="scanlines" />
      <div className="relative mx-auto flex min-h-full w-full max-w-2xl flex-col items-center justify-center px-5 py-10 text-center">
        <div className="animate-fadeup inline-flex items-center gap-2 rounded-full border border-emerald-300/30 bg-emerald-500/10 px-3 py-1">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
          <span className="font-mono text-[10px] tracking-[0.3em] text-emerald-300">
            {caseFile.code} · ЗАКРЫТО
          </span>
        </div>

        <h2 className="animate-fadeup mt-4 text-4xl font-bold text-white sm:text-5xl">
          Дело <span className="text-emerald-300 text-glow">раскрыто</span>
        </h2>
        <p className="mt-2 text-sm text-white/60">{caseFile.subtitle}</p>

        {/* chain graphic */}
        <div className="mt-7 w-full">
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-white/40">
            Доказанная цепочка
          </div>
          <div className="flex flex-col items-stretch gap-2 sm:flex-row">
            {keys.map((e, i) => (
              <div key={e.id} className="flex flex-1 items-center sm:flex-col">
                <div className="flex-1 rounded-2xl border border-white/12 bg-white/[0.04] p-3 text-left sm:text-center">
                  <div className="text-2xl">{e.icon}</div>
                  <div className="mt-1 text-xs font-semibold text-white">{e.title}</div>
                  <div className="mt-0.5 font-mono text-[9px] uppercase tracking-widest text-cyan-300/70">
                    {caseFile.phases.find((p) => p.id === e.phase)?.label}
                  </div>
                </div>
                <div className="px-2 text-white/30 sm:px-0 sm:pt-1">
                  <span className="sm:hidden">↓</span>
                  <span className="hidden sm:inline">→</span>
                </div>
                {i === keys.length - 1 && <div className="hidden sm:block sm:flex-1" />}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 space-y-2 text-left">
          {caseFile.conclusion.map((line, i) => (
            <p
              key={i}
              className="animate-fadeup flex gap-2.5 text-sm leading-relaxed text-white/75"
              style={{ animationDelay: `${0.15 + i * 0.12}s` }}
            >
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-400" />
              {line}
            </p>
          ))}
        </div>

        <button
          onClick={onRestart}
          className="mt-8 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition hover:bg-white/10"
        >
          ↺ Новое дело
        </button>
      </div>
    </div>
  );
}
