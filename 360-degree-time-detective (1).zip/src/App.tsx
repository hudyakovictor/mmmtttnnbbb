import { useCallback, useEffect, useRef, useState } from "react";
import PanoramaViewer from "@/components/PanoramaViewer";
import Hud from "@/components/Hud";
import { EvidenceDetail, CaseFile, EvidenceLog } from "@/components/Panels";
import DeductionBoard from "@/components/DeductionBoard";
import { IntroScreen, WinScreen } from "@/components/Screens";
import { CASE } from "@/game/caseData";
import type { Marker, TimeState } from "@/game/types";

type Phase = "intro" | "play" | "win";
type Panel = null | "case" | "log";

export default function App() {
  const [phase, setPhase] = useState<Phase>("intro");
  const [nodeId, setNodeId] = useState("gallery");
  const [state, setState] = useState<TimeState>("now");
  const [found, setFound] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<Marker | null>(null);
  const [panel, setPanel] = useState<Panel>(null);
  const [deduction, setDeduction] = useState(false);
  const [gyroOn, setGyroOn] = useState(false);
  const [loading, setLoading] = useState(true);
  const [hint, setHint] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | null>(null);

  const node = CASE.nodes.find((n) => n.id === nodeId)!;
  const markers = node.markers.filter((m) => m.states.includes(state));
  const foundEvidence = CASE.evidence.filter((e) => found.has(e.id));
  const keysFound = CASE.keys.filter((k) => found.has(k)).length;
  const totalKeys = CASE.keys.length;
  const canDeduce = keysFound >= totalKeys;

  const flash = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  }, []);

  const onGyroFail = useCallback(() => {
    setGyroOn(false);
    flash("Гироскоп недоступен — используйте свайп");
  }, [flash]);

  /* hint shown briefly when entering the case */
  useEffect(() => {
    if (phase !== "play") return;
    setHint(true);
    const t = window.setTimeout(() => setHint(false), 8000);
    return () => window.clearTimeout(t);
  }, [phase]);

  /* loading flag per panorama */
  useEffect(() => {
    setLoading(true);
  }, [nodeId]);

  const startGame = () => {
    setFound(new Set());
    setNodeId("gallery");
    setState("now");
    setSelected(null);
    setPanel(null);
    setDeduction(false);
    setPhase("play");
  };

  const restart = () => {
    setPhase("intro");
    setFound(new Set());
    setNodeId("gallery");
    setState("now");
    setSelected(null);
    setPanel(null);
    setDeduction(false);
    setGyroOn(false);
  };

  const handleMarker = (m: Marker) => {
    if (m.kind === "nav" && m.navTo) {
      setNodeId(m.navTo);
      return;
    }
    if (m.kind === "info") {
      flash(m.label);
      return;
    }
    if (m.kind === "evidence") setSelected(m);
  };

  const logEvidence = (id: string) => {
    setFound((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      const ev = CASE.evidence.find((e) => e.id === id);
      const nowKeys = CASE.keys.filter((k) => next.has(k)).length;
      if (ev?.key) {
        if (nowKeys >= totalKeys) flash("Все ключевые улики собраны — сформулируйте версию!");
        else flash(`Улика в деле (${nowKeys}/${totalKeys} ключевых)`);
      } else {
        flash("Улика в деле");
      }
      return next;
    });
    setSelected(null);
  };

  const openDeduction = () => {
    if (canDeduce) {
      setPanel(null);
      setDeduction(true);
    } else {
      flash(`Найдите все ${totalKeys} ключевые улики (${keysFound}/${totalKeys})`);
    }
  };

  if (phase === "intro") {
    return <IntroScreen caseFile={CASE} onStart={startGame} />;
  }
  if (phase === "win") {
    return <WinScreen caseFile={CASE} onRestart={restart} />;
  }

  const selectedEvidence = selected?.evidenceId
    ? CASE.evidence.find((e) => e.id === selected.evidenceId)
    : undefined;

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      <PanoramaViewer
        image={node.image}
        u0={node.u0}
        v0={node.v0}
        markers={markers}
        state={state}
        found={found}
        keys={CASE.keys}
        onMarkerClick={handleMarker}
        gyroOn={gyroOn}
        onGyroFail={onGyroFail}
        onReady={() => setLoading(false)}
      />

      {/* atmosphere overlays */}
      <div className="vignette" />
      <div className="scanlines" />
      <div key={`${nodeId}-${state}`} className="scan-sweep" />

      {/* loading veil */}
      {loading && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-sm">
          <div className="relative h-14 w-14">
            <div className="spin-slow absolute inset-0 rounded-full border-2 border-cyan-400/30 border-t-cyan-300" />
            <div className="absolute inset-0 flex items-center justify-center text-xl">🌀</div>
          </div>
          <div className="mt-4 font-mono text-[10px] uppercase tracking-[0.3em] text-cyan-300/80">
            Хроноскан · синхронизация…
          </div>
          <div className="mt-1 text-xs text-white/40">{node.name}</div>
        </div>
      )}

      <Hud
        caseFile={CASE}
        node={node}
        state={state}
        setState={setState}
        foundCount={found.size}
        totalCount={CASE.evidence.length}
        keysFound={keysFound}
        totalKeys={totalKeys}
        onOpenCase={() => setPanel("case")}
        onOpenLog={() => setPanel("log")}
        onOpenDeduction={openDeduction}
        onRestart={restart}
        gyroOn={gyroOn}
        onToggleGyro={() => setGyroOn((g) => !g)}
        showHint={hint}
        onTravel={(id) => setNodeId(id)}
      />

      {/* modals */}
      {selectedEvidence && (
        <EvidenceDetail
          evidence={selectedEvidence}
          node={CASE.nodes.find((n) => n.id === selectedEvidence.node)}
          found={found.has(selectedEvidence.id)}
          onLog={() => logEvidence(selectedEvidence.id)}
          onClose={() => setSelected(null)}
        />
      )}

      {panel === "case" && (
        <CaseFile
          caseFile={CASE}
          foundCount={found.size}
          totalCount={CASE.evidence.length}
          onClose={() => setPanel(null)}
        />
      )}

      {panel === "log" && (
        <EvidenceLog
          items={foundEvidence}
          nodes={CASE.nodes}
          onClose={() => setPanel(null)}
          onOpenDeduction={openDeduction}
          canDeduce={canDeduce}
        />
      )}

      {deduction && (
        <DeductionBoard
          caseFile={CASE}
          keyEvidence={CASE.evidence.filter((e) => e.key)}
          onClose={() => setDeduction(false)}
          onSolved={() => {
            setDeduction(false);
            setPhase("win");
          }}
        />
      )}

      {/* toast */}
      {toast && (
        <div className="pointer-events-none absolute bottom-28 left-1/2 z-50 -translate-x-1/2 px-4">
          <div className="animate-pop rounded-full border border-white/15 bg-slate-950/85 px-5 py-2.5 text-center text-sm text-white shadow-xl backdrop-blur-md">
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}
