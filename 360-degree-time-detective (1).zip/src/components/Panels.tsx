import { useEffect } from "react";
import type { CaseFile, Evidence, PanoNode, TimeState } from "@/game/types";

const STATE_LABEL: Record<TimeState, string> = {
  before: "ДО",
  now: "СЕЙЧАС",
  after: "ПОСЛЕ",
};

function stateChip(s: TimeState) {
  const map: Record<TimeState, string> = {
    before: "border-amber-300/40 bg-amber-500/15 text-amber-200",
    now: "border-rose-300/40 bg-rose-500/15 text-rose-200",
    after: "border-violet-300/40 bg-violet-500/15 text-violet-200",
  };
  return map[s];
}

function Modal({
  onClose,
  children,
  max = "max-w-lg",
}: {
  onClose: () => void;
  children: React.ReactNode;
  max?: string;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onPointerDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm" />
      <div
        className={`animate-pop relative w-full ${max} max-h-[86vh] overflow-hidden rounded-3xl border border-white/12 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl`}
      >
        <button
          onClick={onClose}
          className="absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/15 hover:text-white"
        >
          ✕
        </button>
        {children}
      </div>
    </div>
  );
}

/* ----------------- evidence inspector ----------------- */
export function EvidenceDetail({
  evidence,
  node,
  found,
  onLog,
  onClose,
}: {
  evidence: Evidence;
  node?: PanoNode;
  found: boolean;
  onLog: () => void;
  onClose: () => void;
}) {
  return (
    <Modal onClose={onClose}>
      <div className="thin-scroll max-h-[86vh] overflow-y-auto p-6 sm:p-8">
        <div className="mb-3 flex items-center gap-2">
          <span className={`rounded-full border px-2 py-0.5 font-mono text-[10px] tracking-widest ${stateChip(evidence.state)}`}>
            {STATE_LABEL[evidence.state]}
          </span>
          {node && (
            <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-white/60">
              📍 {node.name}
            </span>
          )}
          {evidence.key && (
            <span className="rounded-full border border-amber-300/40 bg-amber-500/15 px-2 py-0.5 font-mono text-[10px] tracking-widest text-amber-200">
              КЛЮЧЕВАЯ
            </span>
          )}
        </div>

        <div className="flex items-start gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-4xl">
            {evidence.icon}
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white">{evidence.title}</h3>
            <p className="mt-1 text-sm leading-relaxed text-white/70">
              <span className="font-mono text-[10px] uppercase tracking-widest text-cyan-300/80">
                Наблюдение ·{" "}
              </span>
              {evidence.observe}
            </p>
          </div>
        </div>

        <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div className="mb-1 font-mono text-[10px] uppercase tracking-widest text-amber-300/80">
            Вывод следствия
          </div>
          <p className="text-sm leading-relaxed text-white/85">{evidence.infer}</p>
        </div>

        <button
          onClick={onLog}
          disabled={found}
          className={
            "mt-6 w-full rounded-xl py-3 text-sm font-semibold transition " +
            (found
              ? "cursor-default border border-emerald-300/40 bg-emerald-500/15 text-emerald-200"
              : "bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 hover:from-amber-300 hover:to-amber-400")
          }
        >
          {found ? "✓ Уже внесено в дело" : "Внести в дело"}
        </button>
      </div>
    </Modal>
  );
}

/* ----------------- case file ----------------- */
export function CaseFile({
  caseFile,
  foundCount,
  totalCount,
  onClose,
}: {
  caseFile: CaseFile;
  foundCount: number;
  totalCount: number;
  onClose: () => void;
}) {
  return (
    <Modal onClose={onClose}>
      <div className="thin-scroll max-h-[86vh] overflow-y-auto p-6 sm:p-8">
        <div className="font-mono text-[10px] tracking-[0.3em] text-cyan-300/80">
          {caseFile.code} · МАТЕРИАЛЫ
        </div>
        <h3 className="mt-1 text-2xl font-bold text-white">{caseFile.subtitle}</h3>

        <div className="mt-4 space-y-2.5">
          {caseFile.briefing.map((line, i) => (
            <p key={i} className="flex gap-2.5 text-sm leading-relaxed text-white/75">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-cyan-400" />
              {line}
            </p>
          ))}
        </div>

        <div className="mt-5 rounded-2xl border border-amber-300/25 bg-amber-500/[0.07] p-4">
          <div className="mb-1 font-mono text-[10px] uppercase tracking-widest text-amber-300/90">
            Задача
          </div>
          <p className="text-sm leading-relaxed text-white/85">{caseFile.objective}</p>
        </div>

        <div className="mt-5">
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-white/50">
            Цепь доказательств
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {caseFile.phases.map((p, i) => (
              <div
                key={p.id}
                className="rounded-xl border border-white/10 bg-white/[0.03] p-3 text-center"
              >
                <div className="font-mono text-lg text-cyan-300">{i + 1}</div>
                <div className="mt-0.5 text-xs font-semibold text-white">{p.label}</div>
                <div className="mt-0.5 text-[10px] leading-tight text-white/45">{p.desc}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5 flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
          <span className="text-xs text-white/60">Собрано улик</span>
          <span className="font-mono text-sm text-white">
            {foundCount} / {totalCount}
          </span>
        </div>
      </div>
    </Modal>
  );
}

/* ----------------- evidence log drawer ----------------- */
export function EvidenceLog({
  items,
  nodes,
  onClose,
  onOpenDeduction,
  canDeduce,
}: {
  items: Evidence[];
  nodes: PanoNode[];
  onClose: () => void;
  onOpenDeduction: () => void;
  canDeduce: boolean;
}) {
  const nodeName = (id: string) => nodes.find((n) => n.id === id)?.name ?? id;
  return (
    <Modal onClose={onClose} max="max-w-md">
      <div className="thin-scroll max-h-[86vh] overflow-y-auto p-6 sm:p-8">
        <div className="mb-1 font-mono text-[10px] tracking-[0.3em] text-cyan-300/80">
          ПАПКА УЛИК
        </div>
        <h3 className="text-xl font-bold text-white">Изъятое имущество</h3>
        <p className="mt-1 text-xs text-white/50">
          {items.length === 0
            ? "Пока пусто. Ищите несоответствия между эпохами."
            : `${items.length} улик в деле.`}
        </p>

        <div className="mt-4 space-y-2">
          {items.map((e) => (
            <div
              key={e.id}
              className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-xl">
                {e.icon}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate text-sm font-semibold text-white">{e.title}</span>
                  {e.key && (
                    <span className="shrink-0 rounded bg-amber-500/20 px-1 font-mono text-[9px] text-amber-200">
                      KEY
                    </span>
                  )}
                </div>
                <div className="mt-0.5 flex items-center gap-2 text-[10px] text-white/45">
                  <span>📍 {nodeName(e.node)}</span>
                  <span className={`rounded px-1 ${stateChip(e.state)}`}>{STATE_LABEL[e.state]}</span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs leading-snug text-white/55">{e.observe}</p>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onOpenDeduction}
          className={
            "mt-5 w-full rounded-xl py-3 text-sm font-semibold transition " +
            (canDeduce
              ? "bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 hover:from-amber-300 hover:to-amber-400"
              : "border border-white/10 bg-white/5 text-white/40")
          }
        >
          {canDeduce ? "🧩 Сформулировать версию" : "Найдите все 4 ключевые улики"}
        </button>
      </div>
    </Modal>
  );
}
