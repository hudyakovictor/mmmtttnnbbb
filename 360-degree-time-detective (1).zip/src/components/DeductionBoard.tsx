import { useMemo, useState } from "react";
import type { CaseFile, Evidence, Phase } from "@/game/types";

interface DeductionProps {
  caseFile: CaseFile;
  keyEvidence: Evidence[];
  onClose: () => void;
  onSolved: () => void;
}

export default function DeductionBoard({
  caseFile,
  keyEvidence,
  onClose,
  onSolved,
}: DeductionProps) {
  const [assign, setAssign] = useState<Record<Phase, string | null>>({
    setup: null,
    crime: null,
    escape: null,
    aftermath: null,
  });
  const [selected, setSelected] = useState<string | null>(null);
  const [result, setResult] = useState<"idle" | "wrong" | "correct">("idle");
  const [correctCount, setCorrectCount] = useState(0);

  const byId = useMemo(
    () => Object.fromEntries(keyEvidence.map((e) => [e.id, e])),
    [keyEvidence]
  );

  const assignedIds = new Set(Object.values(assign).filter(Boolean));
  const pool = keyEvidence.filter((e) => !assignedIds.has(e.id));
  const allFilled = Object.values(assign).every(Boolean);

  const place = (phase: Phase) => {
    setResult("idle");
    if (assign[phase] && !selected) {
      // empty the slot
      setAssign((a) => ({ ...a, [phase]: null }));
      return;
    }
    if (!selected) return;
    setAssign((a) => ({ ...a, [phase]: selected }));
    setSelected(null);
  };

  const submit = () => {
    let count = 0;
    (Object.keys(assign) as Phase[]).forEach((p) => {
      const id = assign[p];
      if (id && byId[id]?.phase === p) count++;
    });
    setCorrectCount(count);
    if (count === 4) {
      setResult("correct");
    } else {
      setResult("wrong");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" />
      <div className="animate-pop relative flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl border border-white/12 bg-gradient-to-b from-slate-900 to-slate-950 shadow-2xl">
        {/* header */}
        <div className="flex items-center justify-between border-b border-white/10 p-5 sm:px-7">
          <div>
            <div className="font-mono text-[10px] tracking-[0.3em] text-amber-300/80">
              ДОКАЗАТЕЛЬСТВЕННАЯ ЦЕПЬ
            </div>
            <h3 className="text-lg font-bold text-white sm:text-xl">Соберите версию</h3>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/15 hover:text-white"
          >
            ✕
          </button>
        </div>

        <div className="thin-scroll overflow-y-auto p-5 sm:p-7">
          <p className="mb-5 text-xs leading-relaxed text-white/55">
            Расставьте ключевые улики по фазам событий в правильном причинно-следственном
            порядке. Выберите улику, затем — фазу.
          </p>

          {/* phase chain */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-4">
            {caseFile.phases.map((phase, i) => {
              const id = assign[phase.id];
              const ev = id ? byId[id] : null;
              return (
                <div key={phase.id} className="relative">
                  <button
                    onClick={() => place(phase.id)}
                    className={
                      "flex h-full min-h-[120px] w-full flex-col items-center justify-center rounded-2xl border-2 border-dashed p-3 text-center transition " +
                      (ev
                        ? "border-amber-300/50 bg-amber-500/10"
                        : selected
                        ? "border-cyan-300/60 bg-cyan-500/10 hover:bg-cyan-500/20"
                        : "border-white/15 bg-white/[0.02] hover:border-white/30")
                    }
                  >
                    <div className="mb-1 font-mono text-2xl text-cyan-300/80">{i + 1}</div>
                    {ev ? (
                      <>
                        <div className="text-2xl">{ev.icon}</div>
                        <div className="mt-1 text-[11px] font-semibold leading-tight text-white">
                          {ev.title}
                        </div>
                      </>
                    ) : (
                      <div className="text-[11px] font-semibold uppercase tracking-wide text-white/60">
                        {phase.label}
                      </div>
                    )}
                    <div className="mt-1 text-[9px] leading-tight text-white/35">
                      {phase.desc}
                    </div>
                  </button>
                  {i < 3 && (
                    <div className="pointer-events-none absolute -right-2.5 top-1/2 hidden -translate-y-1/2 text-white/30 sm:block">
                      →
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* result line */}
          <div className="mt-4 min-h-[28px] text-center text-xs">
            {result === "wrong" && (
              <span className="font-medium text-rose-300">
                ✗ Версия не сходится. Совпадает {correctCount} из 4. Попробуйте иначе.
              </span>
            )}
            {result === "correct" && (
              <span className="font-medium text-emerald-300">
                ✓ Все фазы на местах. Цепочка доказана.
              </span>
            )}
            {result === "idle" && (
              <span className="text-white/40">
                {allFilled ? "Готово к проверке" : `Расставлено ${4 - pool.length} из 4`}
              </span>
            )}
          </div>

          {/* pool */}
          <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-white/45">
              Улики в работе
            </div>
            {pool.length === 0 ? (
              <div className="py-2 text-center text-xs text-white/35">
                Все улики размещены
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {pool.map((e) => (
                  <button
                    key={e.id}
                    onClick={() => setSelected(selected === e.id ? null : e.id)}
                    className={
                      "flex items-center gap-2 rounded-xl border px-3 py-2 text-sm transition " +
                      (selected === e.id
                        ? "border-cyan-300 bg-cyan-500/20 text-white"
                        : "border-white/12 bg-white/5 text-white/80 hover:bg-white/10")
                    }
                  >
                    <span className="text-lg">{e.icon}</span>
                    <span className="font-medium">{e.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* actions */}
          {result === "correct" ? (
            <button
              onClick={onSolved}
              className="mt-5 w-full rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 py-3.5 text-sm font-bold text-slate-950 transition hover:opacity-90"
            >
              🏆 Раскрыть дело
            </button>
          ) : (
            <button
              onClick={submit}
              disabled={!allFilled}
              className={
                "mt-5 w-full rounded-xl py-3 text-sm font-semibold transition " +
                (allFilled
                  ? "bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 hover:from-amber-300 hover:to-amber-400"
                  : "cursor-not-allowed border border-white/10 bg-white/5 text-white/35")
              }
            >
              Проверить версию
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
