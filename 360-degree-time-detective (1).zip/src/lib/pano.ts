import * as THREE from "three";

const RADIUS = 500;

export interface Projected {
  x: number;
  y: number;
  visible: boolean;
  depth: number;
}

/** Convert image u/v (0..1) into panorama yaw/pitch in degrees.
 *  Geometry is mirrored with scale(-1,1,1) so the equirectangular texture
 *  reads correctly from inside the sphere; yaw sign reflects that. */
export function uvToAngles(u: number, v: number) {
  return { yaw: (0.5 - u) * 360, pitch: 90 - 180 * v };
}

/** World-space direction for a given yaw/pitch (degrees). */
export function dirFromAngles(yawDeg: number, pitchDeg: number): THREE.Vector3 {
  const yaw = THREE.MathUtils.degToRad(yawDeg);
  const pitch = THREE.MathUtils.degToRad(pitchDeg);
  const cp = Math.cos(pitch);
  return new THREE.Vector3(
    -Math.sin(yaw) * cp,
    Math.sin(pitch),
    -Math.cos(yaw) * cp
  );
}

export class PanoScene {
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  private sphere: THREE.Mesh;
  private material: THREE.MeshBasicMaterial;
  private container: HTMLElement;

  private yaw = 0;
  private pitch = 0;
  private velYaw = 0;
  private velPitch = 0;
  private dragging = false;
  private gyroEnabled = false;

  onFrame: (() => void) | null = null;
  onTextureReady: (() => void) | null = null;

  constructor(container: HTMLElement, fov = 74) {
    this.container = container;
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(w, h);

    const canvas = this.renderer.domElement;
    canvas.style.display = "block";
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.touchAction = "none";
    container.appendChild(canvas);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(fov, w / h, 0.1, 1100);
    this.camera.rotation.order = "YXZ";

    const geo = new THREE.SphereGeometry(RADIUS, 80, 60);
    this.material = new THREE.MeshBasicMaterial({ side: THREE.BackSide });
    this.sphere = new THREE.Mesh(geo, this.material);
    this.scene.add(this.sphere);

    window.addEventListener("resize", this.handleResize);
    this.applyRotation();
    this.raf = requestAnimationFrame(this.loop);
  }

  private raf = 0;

  setTexture(url: string) {
    new THREE.TextureLoader().load(url, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.wrapS = THREE.RepeatWrapping;
      tex.minFilter = THREE.LinearFilter;
      tex.offset.x = 0.75;
      this.material.map = tex;
      this.material.needsUpdate = true;
      if (this.onTextureReady) this.onTextureReady();
    });
  }

  setFilter(css: string) {
    this.renderer.domElement.style.filter = css;
  }

  lookAtAngles(yaw: number, pitch: number) {
    this.yaw = yaw;
    this.pitch = Math.max(-80, Math.min(80, pitch));
    this.velYaw = 0;
    this.velPitch = 0;
    this.applyRotation();
  }

  beginDrag() {
    this.dragging = true;
  }
  endDrag() {
    this.dragging = false;
  }
  nudge(dYaw: number, dPitch: number) {
    this.yaw += dYaw;
    this.pitch = Math.max(-80, Math.min(80, this.pitch + dPitch));
    this.velYaw = dYaw;
    this.velPitch = dPitch;
    this.applyRotation();
  }
  setVelocity(y: number, p: number) {
    this.velYaw = y;
    this.velPitch = p;
  }

  getYaw() {
    return this.yaw;
  }
  getPitch() {
    return this.pitch;
  }

  private applyRotation() {
    this.camera.rotation.y = THREE.MathUtils.degToRad(this.yaw);
    this.camera.rotation.x = THREE.MathUtils.degToRad(this.pitch);
  }

  project(yawDeg: number, pitchDeg: number): Projected {
    const dir = dirFromAngles(yawDeg, pitchDeg);
    const pos = dir.multiplyScalar(RADIUS - 6);
    const local = pos.clone().applyMatrix4(this.camera.matrixWorldInverse);
    const inFront = local.z < 0;
    const ndc = pos.clone().project(this.camera);
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    const x = (ndc.x * 0.5 + 0.5) * w;
    const y = (-ndc.y * 0.5 + 0.5) * h;
    return { x, y, visible: inFront, depth: -local.z };
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    if (!this.dragging && (Math.abs(this.velYaw) > 0.0002 || Math.abs(this.velPitch) > 0.0002)) {
      this.yaw += this.velYaw;
      this.pitch = Math.max(-80, Math.min(80, this.pitch + this.velPitch));
      this.velYaw *= 0.92;
      this.velPitch *= 0.92;
      this.applyRotation();
    }
    this.renderer.render(this.scene, this.camera);
    if (this.onFrame) this.onFrame();
  };

  handleResize = () => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    if (!w || !h) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  async enableGyro(): Promise<boolean> {
    const D = (window as unknown as { DeviceOrientationEvent?: typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> } })
      .DeviceOrientationEvent;
    if (!D) return false;
    try {
      if (typeof D.requestPermission === "function") {
        const res = await D.requestPermission();
        if (res !== "granted") return false;
      }
    } catch {
      return false;
    }
    window.addEventListener("deviceorientation", this.onDeviceOrient);
    this.gyroEnabled = true;
    return true;
  }
  disableGyro() {
    this.gyroEnabled = false;
    window.removeEventListener("deviceorientation", this.onDeviceOrient);
  }
  private onDeviceOrient = (e: DeviceOrientationEvent) => {
    if (!this.gyroEnabled) return;
    const alpha = e.alpha ?? 0;
    const beta = e.beta ?? 0;
    this.yaw = -alpha;
    this.pitch = Math.max(-80, Math.min(80, beta - 45));
    this.velYaw = 0;
    this.velPitch = 0;
    this.applyRotation();
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.handleResize);
    window.removeEventListener("deviceorientation", this.onDeviceOrient);
    this.renderer.dispose();
    this.material.map?.dispose();
    this.material.dispose();
    (this.sphere.geometry as THREE.BufferGeometry).dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
