import { EPOCHS, LOCATIONS, PIN_GOAL } from "../game/data";
import type { LocationId, TimeId } from "../game/types";
import { CompassRose } from "./Icons";

export function GameHUD({
  locationId,
  time,
  heading,
  pinnedCount,
  keyPinned,
  hoverName,
  tutorial,
  gyro,
  rain,
  wash,
  shutter,
  onTime,
  onLocation,
  onOpenCase,
  onGyro,
}: {
  locationId: LocationId;
  time: TimeId;
  heading: number;
  pinnedCount: number;
  keyPinned: number;
  hoverName: string | null;
  tutorial: number;
  gyro: boolean;
  rain: boolean;
  wash: string;
  shutter: boolean;
  onTime: (t: TimeId) => void;
  onLocation: (id: LocationId) => void;
  onOpenCase: () => void;
  onGyro: () => void;
}) {
  const loc = LOCATIONS.find((l) => l.id === locationId)!;
  const epoch = EPOCHS.find((e) => e.id === time)!;

  return (
    <>
      <div className="pointer-events-none absolute inset-0 z-20">
        <div className="absolute inset-0" style={{ background: wash, mixBlendMode: "multiply" }} />
        <div className="vignette" />
        <span className="viewfinder-corner left-3 top-3 border-l border-t sm:left-5 sm:top-5" />
        <span className="viewfinder-corner right-3 top-3 border-r border-t sm:right-5 sm:top-5" />
        <span className="viewfinder-corner bottom-28 left-3 border-b border-l sm:bottom-32 sm:left-5" />
        <span className="viewfinder-corner bottom-28 right-3 border-b border-r sm:bottom-32 sm:right-5" />

        <div className="absolute left-1/2 top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2">
          <span className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-white/25" />
          <span className="absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-white/25" />
        </div>

        {rain && <Rain />}
        {shutter && (
          <>
            <div className="shutter-bar top-0 animate-[shutter_0.55s_ease-in] origin-top" />
            <div className="shutter-bar bottom-0 animate-[shutter_0.55s_ease-in] origin-bottom" />
          </>
        )}
      </div>

      <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between p-3 sm:p-5">
        <div className="pointer-events-auto">
          <p className="font-mono text-[9px] uppercase tracking-[0.32em] text-amber-200/55">дело 047 · хроноскоп</p>
          <h2 className="font-serif text-xl leading-tight text-[#f0e2c8] sm:text-2xl">{loc.name}</h2>
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/50">
            {epoch.clock} · {epoch.day}
          </p>
        </div>
        <div className="pointer-events-auto flex items-start gap-2">
          <CompassRose heading={heading} />
          <button
            onClick={onGyro}
            className={`inline-flex h-9 items-center px-2 font-mono text-[9px] uppercase tracking-widest ${
              gyro ? "bg-amber-200/20 text-amber-100" : "bg-black/40 text-white/45"
            }`}
          >
            гиро
          </button>
          <button
            onClick={onOpenCase}
            className="flex h-9 items-center gap-2 border border-amber-200/25 bg-black/45 px-3 font-mono text-[10px] uppercase tracking-[0.18em] text-amber-100 backdrop-blur-sm"
          >
            досье
            <span className="text-rose-300">{pinnedCount}</span>
          </button>
        </div>
      </div>

      {hoverName && (
        <div className="pointer-events-none absolute left-1/2 top-24 z-30 -translate-x-1/2 rounded bg-black/55 px-3 py-1 font-serif text-sm text-amber-50 backdrop-blur-sm">
          {hoverName}
        </div>
      )}

      {tutorial < 3 && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-30 w-[min(92vw,360px)] -translate-x-1/2 translate-y-16 text-center">
          <p className="border border-amber-200/20 bg-black/65 px-4 py-3 font-serif text-[15px] leading-6 text-[#f0e2c8] backdrop-blur-sm">
            {tutorial === 0 && "Поверните улицу — зажмите и тяните. На витрине что-то не так."}
            {tutorial === 1 && "Смахните шкалу на «До». Сравните ту же витрину вчера."}
            {tutorial === 2 && "Закрепите улику и перейдите стрелкой к соседней точке."}
          </p>
        </div>
      )}

      <div className="absolute inset-x-0 bottom-0 z-30 p-3 sm:p-5">
        <div className="mb-3 flex items-end justify-between">
          <MiniMap current={locationId} onPick={onLocation} />
          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-white/35">
            ключ {keyPinned}/{PIN_GOAL}
          </p>
        </div>
        <TimeSlider value={time} onChange={onTime} />
      </div>
    </>
  );
}

function MiniMap({ current, onPick }: { current: LocationId; onPick: (id: LocationId) => void }) {
  const node = (id: LocationId, label: string, extra = "") => (
    <button
      onClick={() => onPick(id)}
      className={`px-2 py-1 font-mono text-[9px] uppercase tracking-[0.14em] ${
        current === id ? "bg-amber-200 text-[#2a2118]" : "bg-black/45 text-white/60 hover:text-white"
      } ${extra}`}
    >
      {label}
    </button>
  );
  return (
    <div className="flex items-center gap-1">
      {node("cafe", "кафе")}
      <span className="text-white/25">—</span>
      {node("gallery", "галерея")}
      <span className="text-white/25">—</span>
      {node("alley", "переулок")}
    </div>
  );
}

function TimeSlider({ value, onChange }: { value: TimeId; onChange: (t: TimeId) => void }) {
  const start = useSwipe(onChange, value);
  return (
    <div
      onPointerDown={start}
      className="grid grid-cols-3 gap-1 border border-white/10 bg-black/50 p-1 backdrop-blur-md"
    >
      {EPOCHS.map((e) => {
        const on = e.id === value;
        return (
          <button
            key={e.id}
            onClick={() => onChange(e.id)}
            className={`px-2 py-2.5 text-left transition ${on ? "bg-amber-200/15 ring-1 ring-amber-200/35" : ""}`}
          >
            <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-amber-100/50">{e.label}</p>
            <p className={`font-serif text-xl leading-none ${on ? "text-[#f0e2c8]" : "text-white/45"}`}>{e.clock}</p>
          </button>
        );
      })}
    </div>
  );
}

function useSwipe(onChange: (t: TimeId) => void, value: TimeId) {
  return (e: { clientX: number }) => {
    const x0 = e.clientX;
    const up = (ev: globalThis.PointerEvent) => {
      const dx = ev.clientX - x0;
      const order: TimeId[] = ["before", "now", "after"];
      const i = order.indexOf(value);
      if (dx < -40 && i < 2) onChange(order[i + 1]);
      if (dx > 40 && i > 0) onChange(order[i - 1]);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointerup", up);
  };
}

function Rain() {
  const drops = Array.from({ length: 42 }, (_, i) => ({
    left: `${(i * 17) % 100}%`,
    delay: `${(i * 0.17) % 1.8}s`,
    dur: `${0.7 + (i % 5) * 0.18}s`,
    h: 10 + (i % 7) * 3,
  }));
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {drops.map((d, i) => (
        <i
          key={i}
          className="absolute top-0 w-px bg-gradient-to-b from-transparent to-white/35"
          style={{
            left: d.left,
            height: d.h,
            animation: `fall ${d.dur} linear ${d.delay} infinite`,
          }}
        />
      ))}
    </div>
  );
}
