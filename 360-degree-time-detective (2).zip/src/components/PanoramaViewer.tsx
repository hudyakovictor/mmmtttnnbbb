import { useEffect, useRef } from "react";
import * as THREE from "three";
import type { Clue, LocationDef, TimeId } from "../game/types";

type Props = {
  location: LocationDef;
  time: TimeId;
  clues: Clue[];
  inspected: Record<string, TimeId[]>;
  pinned: string[];
  lookingHint?: string | null;
  onLook: (lon: number, lat: number) => void;
  onHoverClue: (id: string | null) => void;
  onSelectClue: (id: string) => void;
  onNavigate: (id: LocationDef["id"]) => void;
  gyro: boolean;
};

function sph(yaw: number, pitch: number, r = 220) {
  const phi = THREE.MathUtils.degToRad(90 - pitch);
  const theta = THREE.MathUtils.degToRad(yaw);
  return new THREE.Vector3(
    r * Math.sin(phi) * Math.cos(theta),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(theta),
  );
}

export default function PanoramaViewer({
  location,
  time,
  clues,
  inspected,
  pinned,
  onLook,
  onHoverClue,
  onSelectClue,
  onNavigate,
  gyro,
}: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hudRef = useRef<HTMLDivElement>(null);
  const lookRef = useRef(onLook);
  const hoverRef = useRef(onHoverClue);
  lookRef.current = onLook;
  hoverRef.current = onHoverClue;
  const state = useRef({
    lon: 8,
    lat: 0,
    dragLon: 0,
    dragLat: 0,
    gyroLon: 0,
    gyroLat: 0,
    useGyro: false,
    pointer: false,
    lastX: 0,
    lastY: 0,
    vx: 0,
    vy: 0,
    fov: 72,
    hover: null as string | null,
    tex: null as THREE.Texture | null,
    touched: false,
  });

  useEffect(() => {
    state.current.useGyro = gyro;
  }, [gyro]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x070605, 1);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(72, 1, 0.1, 2000);

    const geom = new THREE.SphereGeometry(500, 72, 52);
    geom.scale(-1, 1, 1);
    const mat = new THREE.MeshBasicMaterial({ color: 0x111111 });
    const sphere = new THREE.Mesh(geom, mat);
    scene.add(sphere);

    const loader = new THREE.TextureLoader();
    loader.setCrossOrigin("anonymous");

    const setSize = () => {
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / Math.max(h, 1);
      camera.updateProjectionMatrix();
    };
    setSize();

    const loadTex = (url: string) => {
      loader.load(url, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.minFilter = THREE.LinearFilter;
        tex.magFilter = THREE.LinearFilter;
        if (state.current.tex) state.current.tex.dispose();
        state.current.tex = tex;
        mat.map = tex;
        mat.color.set(0xffffff);
        mat.needsUpdate = true;
      });
    };
    loadTex(location.panorama);

    const onResize = () => setSize();
    window.addEventListener("resize", onResize);

    const onDown = (e: PointerEvent) => {
      state.current.pointer = true;
      state.current.touched = true;
      state.current.lastX = e.clientX;
      state.current.lastY = e.clientY;
      state.current.vx = 0;
      state.current.vy = 0;
      canvas.setPointerCapture(e.pointerId);
    };
    const onMove = (e: PointerEvent) => {
      if (!state.current.pointer) return;
      const dx = e.clientX - state.current.lastX;
      const dy = e.clientY - state.current.lastY;
      state.current.lastX = e.clientX;
      state.current.lastY = e.clientY;
      state.current.dragLon -= dx * 0.14;
      state.current.dragLat += dy * 0.12;
      state.current.vx = -dx * 0.14;
      state.current.vy = dy * 0.12;
    };
    const onUp = (e: PointerEvent) => {
      state.current.pointer = false;
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {
        /* noop */
      }
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      state.current.fov = THREE.MathUtils.clamp(
        state.current.fov + e.deltaY * 0.04,
        48,
        92,
      );
    };

    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });

    const onOrient = (e: DeviceOrientationEvent) => {
      if (!state.current.useGyro) return;
      if (e.alpha == null || e.beta == null) return;
      state.current.gyroLon = -e.alpha;
      state.current.gyroLat = (e.gamma ?? 0) * 0.15 + (e.beta - 50) * 0.35;
    };
    window.addEventListener("deviceorientation", onOrient);

    let raf = 0;
    const tick = () => {
      const s = state.current;
      if (!s.pointer) {
        if (!s.touched) s.dragLon += 0.045;
        s.dragLon += s.vx;
        s.dragLat += s.vy;
        s.vx *= 0.93;
        s.vy *= 0.93;
      }
      s.dragLat = THREE.MathUtils.clamp(s.dragLat, -72, 72);
      const lon = s.dragLon + (s.useGyro ? s.gyroLon : 0);
      const lat = THREE.MathUtils.clamp(
        s.dragLat + (s.useGyro ? s.gyroLat : 0),
        -78,
        78,
      );
      s.lon = lon;
      s.lat = lat;

      camera.fov += (s.fov - camera.fov) * 0.12;
      camera.updateProjectionMatrix();

      const phi = THREE.MathUtils.degToRad(90 - lat);
      const theta = THREE.MathUtils.degToRad(lon);
      camera.lookAt(
        Math.sin(phi) * Math.cos(theta),
        Math.cos(phi),
        Math.sin(phi) * Math.sin(theta),
      );
      renderer.render(scene, camera);
      lookRef.current(lon, lat);

      const hud = hudRef.current;
      if (hud) {
        const w = wrap.clientWidth;
        const h = wrap.clientHeight;
        const nearest: { id: string | null; d: number } = { id: null, d: Infinity };
        const marks = hud.querySelectorAll<HTMLElement>("[data-mark]");
        marks.forEach((el) => {
          const yaw = Number(el.dataset.yaw);
          const pitch = Number(el.dataset.pitch);
          const v = sph(yaw, pitch, 200);
          v.project(camera);
          const x = (v.x * 0.5 + 0.5) * w;
          const y = (-v.y * 0.5 + 0.5) * h;
          const behind = v.z > 1;
          const onScreen = !behind && x > -40 && x < w + 40 && y > -40 && y < h + 40;
          el.style.display = onScreen ? "flex" : "none";
          el.style.left = `${x}px`;
          el.style.top = `${y}px`;
          const dx = x - w / 2;
          const dy = y - h / 2;
          const d = Math.hypot(dx, dy);
          el.dataset.near = d < 90 ? "1" : "0";
          if (onScreen && el.dataset.kind === "clue" && d < nearest.d) {
            nearest.id = el.dataset.mark ?? null;
            nearest.d = d;
          }
        });
        const hover = nearest.d < 110 ? nearest.id : null;
        if (hover !== s.hover) {
          s.hover = hover;
          hoverRef.current(hover);
        }
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const api = { loadTex, sphere };
    (wrap as unknown as { __pano: typeof api }).__pano = api;

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("deviceorientation", onOrient);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onUp);
      canvas.removeEventListener("wheel", onWheel);
      mat.dispose();
      geom.dispose();
      state.current.tex?.dispose();
      renderer.dispose();
    };
    // init once
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const wrap = wrapRef.current as (HTMLDivElement & { __pano?: { loadTex: (u: string) => void } }) | null;
    wrap?.__pano?.loadTex(location.panorama);
  }, [location]);

  const visibleClues = clues.filter((c) => {
    const loc = c.locationByTime?.[time] ?? c.location;
    return loc === location.id;
  });

  return (
    <div ref={wrapRef} className="absolute inset-0">
      <canvas ref={canvasRef} className="block h-full w-full cursor-grab active:cursor-grabbing" />
      <div ref={hudRef} className="pointer-events-none absolute inset-0 z-10">
        {visibleClues.map((c) => {
          const yaw = c.yawByTime?.[time] ?? c.yaw;
          const pitch = c.pitchByTime?.[time] ?? c.pitch;
          const moment = c.moments[time];
          const seen = inspected[c.id]?.includes(time);
          const isPinned = pinned.includes(c.id);
          if (moment.hidden && !seen) {
            return (
              <button
                key={c.id}
                data-mark={c.id}
                data-kind="clue"
                data-yaw={yaw}
                data-pitch={pitch}
                className="pointer-events-auto absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectClue(c.id);
                }}
              >
                <span className="h-2 w-2 rounded-full bg-white/30 ring-1 ring-white/20" />
              </button>
            );
          }
          return (
            <button
              key={c.id}
              data-mark={c.id}
              data-kind="clue"
              data-yaw={yaw}
              data-pitch={pitch}
              className="group pointer-events-auto absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"
              onClick={(e) => {
                e.stopPropagation();
                onSelectClue(c.id);
              }}
            >
              <span className="relative grid h-9 w-9 place-items-center">
                <span className="absolute inset-0 rounded-full border border-amber-200/70 bg-black/35 backdrop-blur-[2px]" />
                {!seen && (
                  <span className="absolute inset-[-6px] rounded-full border border-amber-300/50 animate-[pulse-ring_2.2s_ease-out_infinite]" />
                )}
                <span
                  className={`relative h-2.5 w-2.5 rounded-full ${
                    isPinned ? "bg-rose-400" : seen ? "bg-amber-200" : "bg-amber-400"
                  } shadow-[0_0_12px_rgba(201,163,106,0.85)]`}
                />
              </span>
              <span className="mt-1 max-w-[140px] truncate rounded-sm bg-black/55 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] text-amber-100/90 opacity-0 backdrop-blur-sm transition group-hover:opacity-100 group-data-[near=1]:opacity-100">
                {c.title}
              </span>
            </button>
          );
        })}
        {location.nav.map((n) => (
          <button
            key={n.to}
            data-mark={`nav-${n.to}`}
            data-kind="nav"
            data-yaw={n.yaw}
            data-pitch={n.pitch}
            className="pointer-events-auto absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1"
            onClick={(e) => {
              e.stopPropagation();
              onNavigate(n.to);
            }}
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 bg-black/40 text-amber-100 shadow-lg backdrop-blur-sm transition hover:border-amber-200/80 hover:bg-black/60">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                <path d="M12 19V5M12 5l-6 6M12 5l6 6" />
              </svg>
            </span>
            <span className="rounded bg-black/60 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-[#e7d8c0]">
              {n.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
