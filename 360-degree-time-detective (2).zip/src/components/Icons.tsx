import type { Clue } from "../game/types";

export function ClueGlyph({ icon, className = "h-4 w-4" }: { icon: Clue["icon"]; className?: string }) {
  const common = {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    className,
  };
  switch (icon) {
    case "window":
      return (
        <svg {...common}>
          <rect x="4" y="3" width="16" height="18" rx="1" />
          <path d="M4 12h16M12 3v18" />
        </svg>
      );
    case "camera":
      return (
        <svg {...common}>
          <circle cx="12" cy="13" r="4" />
          <path d="M4 8h3l2-3h6l2 3h3v12H4z" />
        </svg>
      );
    case "van":
      return (
        <svg {...common}>
          <path d="M3 16V8h11l5 4v4H3z" />
          <circle cx="7.5" cy="17.5" r="1.5" />
          <circle cx="16.5" cy="17.5" r="1.5" />
        </svg>
      );
    case "oil":
      return (
        <svg {...common}>
          <path d="M12 3s6 7 6 11a6 6 0 1 1-12 0c0-4 6-11 6-11z" />
        </svg>
      );
    case "umbrella":
      return (
        <svg {...common}>
          <path d="M12 4c-6 0-9 5-9 7h18c0-2-3-7-9-7z" />
          <path d="M12 11v8a2 2 0 0 0 2 2" />
        </svg>
      );
    case "clock":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8" />
          <path d="M12 8v5l3 2" />
        </svg>
      );
    case "pass":
      return (
        <svg {...common}>
          <rect x="4" y="6" width="16" height="12" rx="1.5" />
          <circle cx="9" cy="12" r="2" />
          <path d="M13 11h5M13 14h4" />
        </svg>
      );
    case "glass":
      return (
        <svg {...common}>
          <path d="M8 4h8l-1 7a4 4 0 0 1-8 0L8 4z" />
          <path d="M12 15v5M9 20h6" />
        </svg>
      );
    case "door":
      return (
        <svg {...common}>
          <path d="M6 21V5l10-2v18z" />
          <path d="M13 12h.5" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <path d="M8 18c0-4 2-7 4-10 2 3 4 6 4 10" />
          <path d="M7 18h10" />
        </svg>
      );
  }
}

export function CompassRose({ heading }: { heading: number }) {
  return (
    <div className="relative h-14 w-14">
      <div
        className="absolute inset-0 rounded-full border border-amber-200/30 bg-black/40 backdrop-blur-sm"
        style={{ transform: `rotate(${-heading}deg)` }}
      >
        <span className="absolute left-1/2 top-1 -translate-x-1/2 font-mono text-[8px] text-rose-300">N</span>
        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 font-mono text-[8px] text-white/40">S</span>
        <span className="absolute left-1 top-1/2 -translate-y-1/2 font-mono text-[8px] text-white/40">W</span>
        <span className="absolute right-1 top-1/2 -translate-y-1/2 font-mono text-[8px] text-white/40">E</span>
        <span className="absolute left-1/2 top-1/2 h-4 w-px -translate-x-1/2 -translate-y-full bg-rose-400" />
      </div>
      <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-200" />
    </div>
  );
}
