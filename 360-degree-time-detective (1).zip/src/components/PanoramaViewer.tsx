import { useEffect, useRef } from "react";
import * as THREE from "three";
import { PanoScene, uvToAngles, dirFromAngles } from "@/lib/pano";
import type { Marker, TimeState } from "@/game/types";

const FILTERS: Record<TimeState, string> = {
  before:
    "saturate(1.18) contrast(1.05) sepia(0.16) brightness(1.05) hue-rotate(-6deg)",
  now: "saturate(1.05) contrast(1.12) brightness(0.97) hue-rotate(-2deg)",
  after: "saturate(0.62) contrast(0.96) brightness(0.9) grayscale(0.28)",
};

interface ViewerProps {
  image: string;
  u0: number;
  v0: number;
  markers: Marker[];
  state: TimeState;
  found: Set<string>;
  keys: string[];
  onMarkerClick: (m: Marker) => void;
  onReady?: () => void;
  gyroOn?: boolean;
  onGyroFail?: () => void;
}

/* ---------- decorative visuals that "edit" the panorama per epoch ---------- */
function Visual({ kind, scale = 1 }: { kind: string; scale?: number }) {
  const px = 96 * scale;
  if (kind === "crack") {
    return (
      <svg
        width={px * 2.2}
        height={px * 2.2}
        viewBox="0 0 200 200"
        style={{ filter: "drop-shadow(0 4px 10px rgba(0,0,0,.55))" }}
      >
        <g
          stroke="rgba(235,242,255,.92)"
          strokeWidth="2.4"
          fill="none"
          strokeLinecap="round"
        >
          <path d="M100 100 L40 30 M100 100 L170 36 M100 100 L32 150 M100 100 L168 158 M100 100 L100 184" />
          <path d="M100 100 L70 60 M100 100 L140 70 M100 100 L64 132 M100 100 L138 128" />
          <circle cx="100" cy="100" r="20" />
          <circle cx="100" cy="100" r="40" opacity="0.5" />
          <circle cx="100" cy="100" r="64" opacity="0.28" />
        </g>
      </svg>
    );
  }
  if (kind === "tape") {
    return (
      <div
        style={{
          width: px * 3,
          transform: "rotate(-7deg)",
          filter: "drop-shadow(0 6px 12px rgba(0,0,0,.5))",
        }}
        className="overflow-hidden rounded-[3px] border border-yellow-300/40"
      >
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="flex items-center justify-center gap-3 bg-yellow-300/95 py-1 text-[10px] font-bold uppercase tracking-[0.25em] text-black/80"
            style={{ borderTop: i ? "1px solid rgba(0,0,0,.25)" : undefined }}
          >
            <span>do not cross</span>
            <span>★</span>
            <span>do not cross</span>
          </div>
        ))}
      </div>
    );
  }
  if (kind === "alarm") {
    return (
      <div style={{ fontSize: px * 0.9, animation: "alarmFlash 0.9s ease-in-out infinite" }}>
        🚨
      </div>
    );
  }
  return <div style={{ fontSize: px }} className="floaty">{emojiFor(kind)}</div>;
}

function emojiFor(kind: string) {
  switch (kind) {
    case "van":
      return "🚐";
    case "sparkle":
      return "✨";
    case "lock":
      return "🔒";
    case "bag":
      return "🎒";
    case "cup":
      return "☕";
    case "door":
      return "🚪";
    default:
      return "•";
  }
}

export default function PanoramaViewer({
  image,
  u0,
  v0,
  markers,
  state,
  found,
  keys,
  onMarkerClick,
  onReady,
  gyroOn,
  onGyroFail,
}: ViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<PanoScene | null>(null);
  const markerEls = useRef<Map<string, HTMLElement>>(new Map());
  const compassEls = useRef<(HTMLDivElement | null)[]>([]);
  const dataRef = useRef({ markers, found, keys });

  // keep latest data available to the rAF loop
  dataRef.current = { markers, found, keys };

  /* mount engine once */
  useEffect(() => {
    if (!containerRef.current) return;
    const scene = new PanoScene(containerRef.current);
    sceneRef.current = scene;
    scene.onFrame = updatePositions;
    scene.onTextureReady = () => onReady?.();
    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* react to node / image changes */
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    const { yaw, pitch } = uvToAngles(u0, v0);
    scene.setTexture(image);
    scene.lookAtAngles(yaw, pitch);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [image, u0, v0]);

  /* react to time-state filter */
  useEffect(() => {
    sceneRef.current?.setFilter(FILTERS[state]);
  }, [state]);

  /* gyroscope toggle */
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    if (!gyroOn) {
      scene.disableGyro();
      return;
    }
    let cancelled = false;
    scene.enableGyro().then((ok) => {
      if (!ok && !cancelled) onGyroFail?.();
    });
    return () => {
      cancelled = true;
      scene.disableGyro();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gyroOn]);

  /* ---------- per-frame marker + compass placement ---------- */
  const updatePositions = () => {
    const scene = sceneRef.current;
    const cont = containerRef.current;
    if (!scene || !cont) return;
    const w = cont.clientWidth;
    const h = cont.clientHeight;
    const { markers: ms, found: f, keys: ks } = dataRef.current;

    const targets: { x: number; y: number; rot: number }[] = [];

    for (const m of ms) {
      const el = markerEls.current.get(m.id);
      if (!el) continue;
      const { yaw, pitch } = uvToAngles(m.u, m.v);
      const p = scene.project(yaw, pitch);
      const onScreen =
        p.visible && p.x > -30 && p.x < w + 30 && p.y > -30 && p.y < h + 30;
      el.style.transform = `translate3d(${p.x}px,${p.y}px,0)`;
      el.style.opacity = onScreen ? "1" : "0";
      el.style.pointerEvents = onScreen ? "auto" : "none";

      if (
        !onScreen &&
        m.kind === "evidence" &&
        m.evidenceId &&
        ks.includes(m.evidenceId) &&
        !f.has(m.evidenceId)
      ) {
        const c = bearingChevron(scene, m, w, h);
        if (c) targets.push(c);
      }
    }

    const pool = compassEls.current;
    for (let i = 0; i < pool.length; i++) {
      const el = pool[i];
      if (!el) continue;
      const t = targets[i];
      if (t) {
        el.style.transform = `translate3d(${t.x}px,${t.y}px,0) rotate(${t.rot}deg)`;
        el.style.opacity = "1";
      } else {
        el.style.opacity = "0";
      }
    }
  };

  /* ---------- pointer drag controls ---------- */
  const last = useRef<{ x: number; y: number } | null>(null);
  const downAt = useRef<{ x: number; y: number; t: number } | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    const scene = sceneRef.current;
    if (!scene) return;
    scene.beginDrag();
    last.current = { x: e.clientX, y: e.clientY };
    downAt.current = { x: e.clientX, y: e.clientY, t: Date.now() };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const scene = sceneRef.current;
    if (!scene || !last.current) return;
    const dx = e.clientX - last.current.x;
    const dy = e.clientY - last.current.y;
    last.current = { x: e.clientX, y: e.clientY };
    const k = 0.15;
    scene.nudge(dx * k, dy * k);
  };
  const endDrag = (e: React.PointerEvent) => {
    const scene = sceneRef.current;
    scene?.endDrag();
    last.current = null;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  };

  const setMarkerEl = (id: string) => (el: HTMLElement | null) => {
    if (el) markerEls.current.set(id, el);
    else markerEls.current.delete(id);
  };

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden bg-black">
      {/* canvas injected here by PanoScene */}

      {/* pointer + markers overlay */}
      <div
        ref={overlayRef}
        className="absolute inset-0 cursor-grab active:cursor-grabbing touch-none"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        {markers.map((m) => (
          <MarkerNode
            key={m.id}
            marker={m}
            found={!!(m.evidenceId && found.has(m.evidenceId))}
            setEl={setMarkerEl(m.id)}
            onClick={() => onMarkerClick(m)}
          />
        ))}

        {/* compass chevrons pointing to off-screen key clues */}
        {keys.map((_, i) => (
          <div
            key={i}
            ref={(el) => {
              compassEls.current[i] = el;
            }}
            className="pointer-events-none absolute left-0 top-0 transition-opacity duration-200"
            style={{ opacity: 0 }}
          >
            <div className="-translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-300/40 bg-cyan-500/15 p-2 backdrop-blur-sm">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 3l7 11h-4v7H9v-7H5z"
                  fill="rgba(120,220,255,.9)"
                  stroke="rgba(255,255,255,.9)"
                  strokeWidth="1"
                />
              </svg>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- individual marker ---------------- */
function MarkerNode({
  marker,
  found,
  setEl,
  onClick,
}: {
  marker: Marker;
  found: boolean;
  setEl: (el: HTMLElement | null) => void;
  onClick: () => void;
}) {
  return (
    <div
      ref={setEl}
      className="pointer-events-none absolute left-0 top-0 transition-opacity duration-150"
      style={{ opacity: 0 }}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="relative -translate-x-1/2 -translate-y-1/2">
        {marker.visual && (
          <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <Visual kind={marker.visual.kind} scale={marker.visual.scale} />
          </div>
        )}

        {marker.kind === "nav" ? (
          <button
            onClick={onClick}
            className="group pointer-events-auto relative flex items-center gap-2 rounded-full border border-cyan-300/40 bg-slate-950/55 px-3 py-1.5 backdrop-blur-md transition hover:scale-105 hover:border-cyan-200/80 hover:bg-cyan-500/20"
          >
            <span className="text-cyan-200 transition group-hover:translate-x-0.5">➜</span>
            <span className="whitespace-nowrap text-xs font-semibold tracking-wide text-cyan-50">
              {marker.label}
            </span>
          </button>
        ) : marker.kind === "info" ? (
          <button
            onClick={onClick}
            className="pointer-events-auto flex h-7 w-7 items-center justify-center rounded-full border border-white/30 bg-slate-900/50 text-xs text-white/80 backdrop-blur-sm transition hover:bg-white/20"
            title={marker.label}
          >
            i
          </button>
        ) : (
          <button
            onClick={onClick}
            className={
              "pointer-events-auto relative flex h-7 w-7 items-center justify-center rounded-full border backdrop-blur-sm transition " +
              (found
                ? "border-emerald-300/70 bg-emerald-500/30 text-emerald-100"
                : "border-amber-300/70 bg-amber-500/25 text-amber-100")
            }
          >
            {!found && <span className="ev-ring absolute inset-0 rounded-full" />}
            <span className="relative text-xs">{found ? "✓" : "?"}</span>
          </button>
        )}

        {/* label chip: only reveal once logged (evidence) or for info notes */}
        {(marker.kind === "info" || found) && (
          <div className="pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded bg-slate-950/75 px-2 py-0.5 text-[10px] font-medium tracking-wide text-white/80 backdrop-blur-sm">
            {marker.label}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- compass math ---------- */
function bearingChevron(
  scene: PanoScene,
  m: Marker,
  w: number,
  h: number
): { x: number; y: number; rot: number } | null {
  const camYaw = scene.getYaw();
  const camDir = dirFromAngles(camYaw, 0);
  camDir.y = 0;
  camDir.normalize();
  const camRight = new THREE.Vector3(-camDir.z, 0, camDir.x);

  const { yaw: myaw } = uvToAngles(m.u, m.v);
  const mdir = dirFromAngles(myaw, 0);
  mdir.y = 0;
  mdir.normalize();

  const fwd = mdir.dot(camDir);
  const right = mdir.dot(camRight);
  const a = Math.atan2(right, fwd); // 0 = ahead, += right

  const radiusX = w / 2 - 70;
  const radiusY = h / 2 - 96;
  const x = w / 2 + Math.sin(a) * radiusX;
  const y = h / 2 - Math.cos(a) * radiusY;
  return { x, y, rot: (a * 180) / Math.PI };
}
