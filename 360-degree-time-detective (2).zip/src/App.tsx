import { useEffect, useMemo, useRef, useState } from "react";
import { CaseFile as CaseFilePanel, DeductionBoard, InspectModal, TimeFlash } from "./components/CaseUI";
import { GameHUD } from "./components/GameHUD";
import PanoramaViewer from "./components/PanoramaViewer";
import { BootScreen, BriefingScreen, IntroScreen, VerdictScreen } from "./components/Screens";
import { createAudio, type AudioApi } from "./game/audio";
import { panoramas } from "./game/assets";
import {
  CLUES,
  KEY_CLUES,
  PIN_GOAL,
  QUESTIONS,
  clueById,
  epochById,
  locationById,
} from "./game/data";
import type { LocationId, Phase, TimeId } from "./game/types";

export default function App() {
  const audio = useRef<AudioApi | null>(null);
  const [phase, setPhase] = useState<Phase>("boot");
  const [boot, setBoot] = useState(0);
  const [locationId, setLocationId] = useState<LocationId>("gallery");
  const [time, setTime] = useState<TimeId>("now");
  const [heading, setHeading] = useState(0);
  const [hover, setHover] = useState<string | null>(null);
  const [inspectId, setInspectId] = useState<string | null>(null);
  const [inspected, setInspected] = useState<Record<string, TimeId[]>>({});
  const [pinned, setPinned] = useState<string[]>([]);
  const [caseOpen, setCaseOpen] = useState(false);
  const [deduceOpen, setDeduceOpen] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [score, setScore] = useState(0);
  const [tutorial, setTutorial] = useState(0);
  const [gyro, setGyro] = useState(false);
  const [flash, setFlash] = useState(false);
  const [shutter, setShutter] = useState(false);
  const [looked, setLooked] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "1") changeTime("before");
      if (e.key === "2") changeTime("now");
      if (e.key === "3") changeTime("after");
      if (e.key === "Escape") {
        setInspectId(null);
        setCaseOpen(false);
        setDeduceOpen(false);
      }
      if (e.key === "j" || e.key === "J") setCaseOpen((v) => !v);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  useEffect(() => {
    audio.current = createAudio();
    const urls = Object.values(panoramas);
    let done = 0;
    urls.forEach((src) => {
      const img = new Image();
      img.onload = img.onerror = () => {
        done += 1;
        setBoot(Math.round((done / urls.length) * 100));
        if (done >= urls.length) setTimeout(() => setPhase("intro"), 420);
      };
      img.src = src;
    });
    return () => audio.current?.stop();
  }, []);

  const location = locationById(locationId);
  const epoch = epochById(time);
  const inspectClue = inspectId ? clueById(inspectId) : null;
  const keyPinned = pinned.filter((id) => KEY_CLUES.some((c) => c.id === id)).length;
  const canDeduce = keyPinned >= PIN_GOAL;
  const hoverName = hover ? (CLUES.find((c) => c.id === hover)?.title ?? null) : null;

  const markSeen = (id: string, t: TimeId) => {
    setInspected((prev) => {
      const cur = prev[id] ?? [];
      if (cur.includes(t)) return prev;
      return { ...prev, [id]: [...cur, t] };
    });
  };

  const changeTime = (next: TimeId) => {
    if (next === time) return;
    audio.current?.shutter();
    setShutter(true);
    setFlash(true);
    setTime(next);
    if (tutorial === 1) setTutorial(2);
    window.setTimeout(() => setShutter(false), 560);
    window.setTimeout(() => setFlash(false), 900);
  };

  const changeLocation = (id: LocationId) => {
    if (id === locationId) return;
    audio.current?.whoosh();
    setShutter(true);
    setLocationId(id);
    if (tutorial === 2) setTutorial(3);
    window.setTimeout(() => setShutter(false), 500);
  };

  const openClue = (id: string) => {
    audio.current?.mark();
    markSeen(id, time);
    setInspectId(id);
    if (tutorial === 0) setTutorial(1);
  };

  const pinClue = () => {
    if (!inspectId) return;
    audio.current?.pin();
    setPinned((p) => (p.includes(inspectId) ? p : [...p, inspectId]));
    if (tutorial === 2) setTutorial(2);
  };

  const submitDeduction = () => {
    const n = QUESTIONS.filter((q) => q.options.find((o) => o.id === answers[q.id])?.correct).length;
    setScore(n);
    audio.current?.resolve();
    setPhase("verdict");
  };

  const enableGyro = async () => {
    const Doe = DeviceOrientationEvent as unknown as {
      requestPermission?: () => Promise<string>;
    };
    try {
      if (typeof Doe.requestPermission === "function") {
        const res = await Doe.requestPermission();
        if (res !== "granted") return;
      }
      setGyro((g) => !g);
    } catch {
      setGyro((g) => !g);
    }
  };

  const onLook = useMemo(() => {
    let last = 0;
    return (lon: number, _lat: number) => {
      const now = performance.now();
      if (now - last < 80) return;
      last = now;
      setHeading(lon);
      if (!looked && Math.abs(lon) > 18) {
        setLooked(true);
        if (tutorial === 0) setTutorial(1);
      }
    };
  }, [looked, tutorial]);

  if (phase === "boot") return <BootScreen progress={boot} />;
  if (phase === "intro") {
    return (
      <IntroScreen
        onNext={() => {
          audio.current?.resume();
          audio.current?.tick();
          setPhase("briefing");
        }}
      />
    );
  }
  if (phase === "briefing") {
    return (
      <BriefingScreen
        onStart={() => {
          audio.current?.shutter();
          setPhase("game");
        }}
      />
    );
  }
  if (phase === "verdict") {
    return (
      <VerdictScreen
        correct={score}
        total={QUESTIONS.length}
        onReplay={() => {
          setPhase("game");
          setDeduceOpen(false);
          setCaseOpen(false);
        }}
      />
    );
  }

  return (
    <div className="grain relative h-full w-full overflow-hidden bg-black">
      <div
        className="absolute inset-0 transition-[filter] duration-700"
        style={{ filter: epoch.filter }}
      >
        <PanoramaViewer
          location={location}
          time={time}
          clues={CLUES}
          inspected={inspected}
          pinned={pinned}
          onLook={onLook}
          onHoverClue={setHover}
          onSelectClue={openClue}
          onNavigate={changeLocation}
          gyro={gyro}
        />
      </div>

      <GameHUD
        locationId={locationId}
        time={time}
        heading={heading}
        pinnedCount={pinned.length}
        keyPinned={keyPinned}
        hoverName={hoverName}
        tutorial={tutorial}
        gyro={gyro}
        rain={epoch.rain}
        wash={epoch.wash}
        shutter={shutter}
        onTime={changeTime}
        onLocation={changeLocation}
        onOpenCase={() => {
          audio.current?.tick();
          setCaseOpen(true);
        }}
        onGyro={() => void enableGyro()}
      />

      {flash && <TimeFlash time={time} />}

      {inspectClue && (
        <InspectModal
          clue={inspectClue}
          time={time}
          seen={inspected[inspectClue.id] ?? []}
          pinned={pinned.includes(inspectClue.id)}
          onClose={() => setInspectId(null)}
          onPin={pinClue}
          onSwitchTime={(t) => {
            changeTime(t);
            markSeen(inspectClue.id, t);
          }}
        />
      )}

      {caseOpen && (
        <CaseFilePanel
          inspected={inspected}
          pinned={pinned}
          canDeduce={canDeduce}
          onClose={() => setCaseOpen(false)}
          onOpenDeduction={() => {
            if (!canDeduce) return;
            setCaseOpen(false);
            setDeduceOpen(true);
          }}
        />
      )}

      {deduceOpen && (
        <DeductionBoard
          answers={answers}
          onAnswer={(q, o) => {
            audio.current?.tick();
            setAnswers((a) => ({ ...a, [q]: o }));
          }}
          onClose={() => setDeduceOpen(false)}
          onSubmit={submitDeduction}
        />
      )}

      <HelpFab
        onResetLook={() => {
          setTutorial(0);
        }}
      />
    </div>
  );
}

function HelpFab({ onResetLook }: { onResetLook: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="absolute bottom-36 right-3 z-30 sm:bottom-40 sm:right-5">
      <button
        onClick={() => setOpen((v) => !v)}
        className="grid h-9 w-9 place-items-center border border-white/15 bg-black/50 font-serif text-lg text-amber-100/70"
      >
        ?
      </button>
      {open && (
        <div className="absolute bottom-11 right-0 w-56 border border-white/10 bg-black/80 p-3 text-[11px] leading-5 text-white/60 backdrop-blur-md">
          <p>Тяните обзор. Колёсико — зум.</p>
          <p>1 / 2 / 3 — эпохи. Карта внизу — точки улицы.</p>
          <p>Сравните объект во всех трёх временах, затем закрепите.</p>
          <button onClick={onResetLook} className="mt-2 font-mono uppercase tracking-widest text-amber-200/70">
            подсказка снова
          </button>
        </div>
      )}
    </div>
  );
}


