import { CLUES, EPOCHS, PIN_GOAL, QUESTIONS, THREADS, epochById } from "../game/data";
import type { Clue, TimeId } from "../game/types";
import { ClueGlyph } from "./Icons";

export function InspectModal({
  clue,
  time,
  seen,
  pinned,
  onClose,
  onPin,
  onSwitchTime,
}: {
  clue: Clue;
  time: TimeId;
  seen: TimeId[];
  pinned: boolean;
  onClose: () => void;
  onPin: () => void;
  onSwitchTime: (t: TimeId) => void;
}) {
  const moment = clue.moments[time];
  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center bg-black/50 p-3 sm:items-center">
      <button className="absolute inset-0 cursor-default" onClick={onClose} aria-label="Закрыть" />
      <div className="relative w-full max-w-xl overflow-hidden border border-amber-200/20 bg-[#100e0c]/95 shadow-2xl backdrop-blur-md">
        {moment.photo && (
          <div className="relative h-40 overflow-hidden sm:h-52">
            <img src={moment.photo} alt="" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#100e0c] to-transparent" />
          </div>
        )}
        <div className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-amber-200/50">
                объект · {clue.title}
              </p>
              <h3 className="mt-1 font-serif text-2xl text-[#f0e2c8]">{moment.headline}</h3>
            </div>
            <span className="grid h-9 w-9 place-items-center border border-amber-200/20 text-amber-100/80">
              <ClueGlyph icon={clue.icon} />
            </span>
          </div>
          <p className="mt-3 text-sm leading-6 text-white/70">{moment.body}</p>

          <div className="mt-5 grid grid-cols-3 gap-1.5">
            {EPOCHS.map((e) => {
              const known = seen.includes(e.id);
              const active = e.id === time;
              return (
                <button
                  key={e.id}
                  onClick={() => onSwitchTime(e.id)}
                  className={`px-2 py-2 text-left transition ${
                    active
                      ? "bg-amber-200/15 ring-1 ring-amber-200/40"
                      : "bg-white/5 hover:bg-white/8"
                  }`}
                >
                  <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-amber-100/55">
                    {e.short} {e.clock}
                  </p>
                  <p className="mt-1 line-clamp-2 text-[11px] leading-4 text-white/70">
                    {known ? clue.moments[e.id].headline : "переключите эпоху"}
                  </p>
                </button>
              );
            })}
          </div>

          <div className="mt-5 flex gap-2">
            <button
              onClick={onPin}
              className={`flex-1 py-3 font-mono text-[11px] uppercase tracking-[0.22em] ${
                pinned
                  ? "border border-rose-400/40 bg-rose-400/10 text-rose-200"
                  : "bg-amber-200/90 text-[#2a2118] hover:bg-amber-100"
              }`}
            >
              {pinned ? "улика закреплена" : "закрепить как улику"}
            </button>
            <button
              onClick={onClose}
              className="border border-white/15 px-4 font-mono text-[11px] uppercase tracking-[0.18em] text-white/60"
            >
              закрыть
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CaseFile({
  inspected,
  pinned,
  onClose,
  onOpenDeduction,
  canDeduce,
}: {
  inspected: Record<string, TimeId[]>;
  pinned: string[];
  onClose: () => void;
  onOpenDeduction: () => void;
  canDeduce: boolean;
}) {
  const items = CLUES.filter((c) => pinned.includes(c.id) || inspected[c.id]?.length);
  const threads = THREADS.filter((t) => t.need.every((id) => pinned.includes(id)));

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 p-3">
      <button className="absolute inset-0" onClick={onClose} aria-label="Закрыть" />
      <div className="paper-sheet relative max-h-[92vh] w-full max-w-2xl overflow-auto p-6 sm:p-8">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#7a4b2a]">досье · дело 047</p>
            <h3 className="font-serif text-3xl text-[#2a2118]">Журнал улик</h3>
          </div>
          <button onClick={onClose} className="font-mono text-[11px] uppercase tracking-widest text-[#6b4a2d]">
            закрыть
          </button>
        </div>

        <p className="mt-2 font-mono text-[11px] text-[#6b4a2d]">
          закреплено {pinned.length} · нужно {PIN_GOAL} ключевых, чтобы собрать версию
        </p>

        <div className="mt-5 space-y-3">
          {items.length === 0 && (
            <p className="text-sm text-[#6b4a2d]">Пока пусто. Найдите несоответствие на витрине.</p>
          )}
          {items.map((c) => {
            const times = inspected[c.id] ?? [];
            return (
              <div key={c.id} className="flex gap-3 border-b border-[#2a2118]/10 pb-3">
                <div className="mt-1 text-[#6b4a2d]">
                  <ClueGlyph icon={c.icon} className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-baseline gap-2">
                    <p className="font-serif text-lg text-[#2a2118]">{c.title}</p>
                    {pinned.includes(c.id) && (
                      <span className="font-mono text-[9px] uppercase tracking-widest text-[#8f2d3a]">улика</span>
                    )}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {EPOCHS.map((e) => (
                      <span
                        key={e.id}
                        className={`px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider ${
                          times.includes(e.id) ? "bg-[#2a2118] text-[#e7d8c0]" : "bg-[#2a2118]/10 text-[#6b4a2d]"
                        }`}
                      >
                        {e.clock}
                      </span>
                    ))}
                  </div>
                  {times.length > 0 && (
                    <p className="mt-1 text-sm leading-5 text-[#4a3b2c]">
                      {c.moments[times[times.length - 1]].headline}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {threads.length > 0 && (
          <div className="mt-6 space-y-3">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-[#8f2d3a]">связанные нити</p>
            {threads.map((t) => (
              <div key={t.id} className="bg-[#8f2d3a]/8 p-3">
                <p className="font-serif text-lg text-[#2a2118]">{t.title}</p>
                <p className="mt-1 text-sm leading-6 text-[#3c2f24]">{t.text}</p>
              </div>
            ))}
          </div>
        )}

        <button
          onClick={onOpenDeduction}
          disabled={!canDeduce}
          className="mt-8 w-full bg-[#2a2118] py-3 font-mono text-[11px] uppercase tracking-[0.28em] text-[#e7d8c0] disabled:opacity-35"
        >
          {canDeduce ? "собрать версию" : `ещё улик: ${Math.max(0, PIN_GOAL - pinned.filter((id) => CLUES.find((c) => c.id === id)?.key).length)}`}
        </button>
      </div>
    </div>
  );
}

export function DeductionBoard({
  answers,
  onAnswer,
  onClose,
  onSubmit,
}: {
  answers: Record<string, string>;
  onAnswer: (qid: string, oid: string) => void;
  onClose: () => void;
  onSubmit: () => void;
}) {
  const ready = QUESTIONS.every((q) => answers[q.id]);
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-3">
      <div className="relative max-h-[92vh] w-full max-w-2xl overflow-auto border border-amber-200/20 bg-[#0d0b09] p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-amber-200/50">граф доказательств</p>
            <h3 className="font-serif text-3xl text-[#f0e2c8]">Соберите цепочку</h3>
          </div>
          <button onClick={onClose} className="font-mono text-[11px] uppercase text-white/40">
            назад
          </button>
        </div>
        <div className="mt-6 space-y-6">
          {QUESTIONS.map((q, i) => (
            <div key={q.id}>
              <p className="font-mono text-[10px] text-amber-200/45">вопрос 0{i + 1}</p>
              <p className="font-serif text-xl text-[#f0e2c8]">{q.prompt}</p>
              <p className="mt-1 text-xs text-white/35">{q.hint}</p>
              <div className="mt-3 grid gap-2">
                {q.options.map((o) => {
                  const on = answers[q.id] === o.id;
                  return (
                    <button
                      key={o.id}
                      onClick={() => onAnswer(q.id, o.id)}
                      className={`px-3 py-2.5 text-left text-sm leading-5 transition ${
                        on
                          ? "bg-amber-200/15 text-amber-50 ring-1 ring-amber-200/40"
                          : "bg-white/4 text-white/65 hover:bg-white/8"
                      }`}
                    >
                      {o.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        <button
          disabled={!ready}
          onClick={onSubmit}
          className="mt-8 w-full bg-amber-200/90 py-3 font-mono text-[11px] uppercase tracking-[0.28em] text-[#2a2118] disabled:opacity-30"
        >
          зафиксировать версию
        </button>
      </div>
    </div>
  );
}

export function TimeFlash({ time }: { time: TimeId }) {
  const e = epochById(time);
  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
      <div className="text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.5em] text-amber-100/80">{e.short}</p>
        <p className="font-serif text-6xl text-white sm:text-7xl">{e.clock}</p>
        <p className="mt-2 font-serif italic text-white/70">{e.caption}</p>
      </div>
    </div>
  );
}
