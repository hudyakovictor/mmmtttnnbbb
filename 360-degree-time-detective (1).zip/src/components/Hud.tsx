import { useRef } from "react";
import type { CaseFile, PanoNode, TimeState } from "@/game/types";

const STATES: TimeState[] = ["before", "now", "after"];

const META: Record<
  TimeState,
  { short: string; label: string; sub: string; dot: string; ring: string; text: string }
> = {
  before: {
    short: "−24ч",
    label: "ДО",
    sub: "Сутки назад",
    dot: "bg-amber-300",
    ring: "ring-amber-300/60",
    text: "text-amber-200",
  },
  now: {
    short: "00:00",
    label: "СЕЙЧАС",
    sub: "Момент ЧП",
    dot: "bg-rose-400",
    ring: "ring-rose-400/60",
    text: "text-rose-200",
  },
  after: {
    short: "+24ч",
    label: "ПОСЛЕ",
    sub: "Сутки спустя",
    dot: "bg-violet-300",
    ring: "ring-violet-300/60",
    text: "text-violet-200",
  },
};

interface HudProps {
  caseFile: CaseFile;
  node: PanoNode;
  state: TimeState;
  setState: (s: TimeState) => void;
  foundCount: number;
  totalCount: number;
  keysFound: number;
  totalKeys: number;
  onOpenCase: () => void;
  onOpenLog: () => void;
  onOpenDeduction: () => void;
  onRestart: () => void;
  gyroOn: boolean;
  onToggleGyro: () => void;
  showHint: boolean;
  onTravel: (target: string) => void;
}

export default function Hud(props: HudProps) {
  const {
    caseFile,
    node,
    state,
    setState,
    foundCount,
    totalCount,
    keysFound,
    totalKeys,
    onOpenCase,
    onOpenLog,
    onOpenDeduction,
    onRestart,
    gyroOn,
    onToggleGyro,
    showHint,
    onTravel,
  } = props;

  const allKeys = keysFound >= totalKeys;
  const exits = node.markers.filter((m) => m.kind === "nav");

  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex flex-col justify-between">
      {/* ---------- top bar ---------- */}
      <div className="flex items-start justify-between gap-3 p-3 sm:p-4">
        <div className="pointer-events-auto rounded-2xl border border-white/10 bg-slate-950/55 px-3 py-2 backdrop-blur-md sm:px-4">
          <div className="font-mono text-[10px] tracking-[0.3em] text-cyan-300/80">
            {caseFile.code}
          </div>
          <div className="text-sm font-semibold leading-tight text-white sm:text-base">
            {caseFile.title}
          </div>
          <div className="mt-0.5 flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${META[state].dot} animate-pulse`} />
            <span className="text-[11px] text-white/60">{node.name}</span>
          </div>
        </div>

        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
          <button
            onClick={onOpenLog}
            className="group relative flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-950/55 px-3 py-2 text-xs font-medium text-white/85 backdrop-blur-md transition hover:bg-white/10"
          >
            <span>📁</span>
            <span className="hidden sm:inline">Улики</span>
            <span className="rounded-md bg-white/10 px-1.5 py-0.5 font-mono text-[10px]">
              {foundCount}/{totalCount}
            </span>
          </button>

          <button
            onClick={onOpenDeduction}
            className={
              "relative flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-semibold backdrop-blur-md transition " +
              (allKeys
                ? "border-amber-300/60 bg-amber-500/20 text-amber-100 hover:bg-amber-500/30"
                : "border-white/10 bg-slate-950/55 text-white/85 hover:bg-white/10")
            }
          >
            <span>🧩</span>
            <span className="hidden sm:inline">Версия</span>
            <span className="rounded-md bg-black/30 px-1.5 py-0.5 font-mono text-[10px]">
              {keysFound}/{totalKeys}
            </span>
            {allKeys && (
              <span className="absolute -right-1 -top-1 flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-300 opacity-70" />
                <span className="relative inline-flex h-3 w-3 rounded-full bg-amber-400" />
              </span>
            )}
          </button>

          <button
            onClick={onOpenCase}
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-950/55 px-3 py-2 text-xs font-medium text-white/85 backdrop-blur-md transition hover:bg-white/10"
            title="Материалы дела"
          >
            <span>📄</span>
            <span className="hidden sm:inline">Дело</span>
          </button>

          <button
            onClick={onToggleGyro}
            className={
              "flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-medium backdrop-blur-md transition " +
              (gyroOn
                ? "border-cyan-300/60 bg-cyan-500/20 text-cyan-100"
                : "border-white/10 bg-slate-950/55 text-white/70 hover:bg-white/10")
            }
            title="Гироскоп"
          >
            <span>📱</span>
            <span className="hidden md:inline">{gyroOn ? "Гиро вкл" : "Гиро"}</span>
          </button>

          <button
            onClick={onRestart}
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-slate-950/55 px-3 py-2 text-xs font-medium text-white/70 backdrop-blur-md transition hover:bg-white/10"
            title="Заново"
          >
            <span>↺</span>
          </button>
        </div>
      </div>

      {/* ---------- center hint ---------- */}
      {showHint && (
        <div className="pointer-events-none flex justify-center px-4">
          <div className="animate-fadeup rounded-full border border-white/10 bg-slate-950/60 px-4 py-2 text-center text-[11px] text-white/75 backdrop-blur-md sm:text-xs">
            Перетаскивайте вид · смахните <b className="text-white">шкалу времени</b> ·
            нажимайте на <b className="text-amber-200">метки улик</b> · идите по стрелкам
          </div>
        </div>
      )}

      {/* ---------- bottom: exits + timeline ---------- */}
      <div className="space-y-2 p-3 sm:p-5">
        {exits.length > 0 && (
          <div className="pointer-events-auto flex flex-wrap justify-center gap-2">
            {exits.map((m) => (
              <button
                key={m.id}
                onClick={() => m.navTo && onTravel(m.navTo)}
                className="flex items-center gap-1.5 rounded-full border border-cyan-300/30 bg-slate-950/55 px-3 py-1.5 text-xs font-medium text-cyan-50 backdrop-blur-md transition hover:border-cyan-200/70 hover:bg-cyan-500/20"
              >
                <span className="text-cyan-300">➜</span>
                {m.label}
              </button>
            ))}
          </div>
        )}
        <Timeline state={state} setState={setState} />
      </div>
    </div>
  );
}

function Timeline({
  state,
  setState,
}: {
  state: TimeState;
  setState: (s: TimeState) => void;
}) {
  const trackRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const pick = (clientX: number) => {
    const el = trackRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const f = (clientX - r.left) / r.width;
    const idx = Math.max(0, Math.min(2, Math.round(f * 2)));
    setState(STATES[idx]);
  };

  const idx = STATES.indexOf(state);

  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-1.5 flex items-center justify-between px-1">
        <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-white/45">
          Хроноскан · эпоха
        </span>
        <span className={`font-mono text-[10px] uppercase tracking-[0.25em] ${META[state].text}`}>
          {META[state].label} — {META[state].sub}
        </span>
      </div>

      <div
        ref={trackRef}
        onPointerDown={(e) => {
          dragging.current = true;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
          pick(e.clientX);
        }}
        onPointerMove={(e) => dragging.current && pick(e.clientX)}
        onPointerUp={(e) => {
          dragging.current = false;
          (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
        }}
        className="relative flex touch-none cursor-pointer select-none gap-1.5 rounded-2xl border border-white/10 bg-slate-950/55 p-1.5 backdrop-blur-md"
      >
        {/* sliding highlight */}
        <div
          className="pointer-events-none absolute inset-y-1.5 rounded-xl bg-white/10 transition-all duration-300"
          style={{
            left: `calc(${(idx / 3) * 100}% + 6px)`,
            width: `calc(${100 / 3}% - 9px)`,
          }}
        />
        {STATES.map((s, i) => {
          const active = s === state;
          return (
            <button
              key={s}
              onClick={() => setState(s)}
              className={
                "relative z-10 flex flex-1 flex-col items-center rounded-xl py-2 transition " +
                (active ? META[s].text : "text-white/45 hover:text-white/70")
              }
            >
              <span className="flex items-center gap-1.5">
                <span className={`h-1.5 w-1.5 rounded-full ${active ? META[s].dot : "bg-white/30"}`} />
                <span className="font-mono text-[11px] font-bold tracking-wider">
                  {META[s].short}
                </span>
              </span>
              <span className="text-[9px] uppercase tracking-[0.2em] opacity-80">
                {META[s].label}
              </span>
              {/* connectors */}
              {i < 2 && (
                <span className="absolute right-[-9px] top-1/2 h-px w-3 -translate-y-1/2 bg-white/15" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
