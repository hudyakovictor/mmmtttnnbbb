export type AudioApi = {
  resume: () => void;
  tick: () => void;
  pin: () => void;
  shutter: () => void;
  whoosh: () => void;
  mark: () => void;
  wrong: () => void;
  resolve: () => void;
  stop: () => void;
};

function makeNoise(ctx: AudioContext, duration: number, gain = 0.04) {
  const buffer = ctx.createBuffer(1, ctx.sampleRate * duration, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  const g = ctx.createGain();
  g.gain.value = gain;
  src.connect(g).connect(ctx.destination);
  src.start();
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
}

export function createAudio(): AudioApi {
  let ctx: AudioContext | null = null;

  const ac = () => {
    if (!ctx) ctx = new AudioContext();
    return ctx;
  };

  const tone = (
    freq: number,
    dur: number,
    type: OscillatorType = "sine",
    volume = 0.05,
    delay = 0,
  ) => {
    const c = ac();
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = 0.0001;
    osc.connect(g).connect(c.destination);
    const t = c.currentTime + delay;
    osc.start(t);
    g.gain.exponentialRampToValueAtTime(volume, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.stop(t + dur + 0.02);
  };

  return {
    resume: () => {
      void ac().resume();
    },
    tick: () => {
      tone(920, 0.045, "square", 0.03);
      tone(460, 0.06, "triangle", 0.02);
    },
    pin: () => {
      tone(392, 0.08, "triangle", 0.05);
      tone(587, 0.12, "sine", 0.045, 0.05);
      tone(784, 0.16, "sine", 0.03, 0.1);
    },
    shutter: () => {
      makeNoise(ac(), 0.09, 0.05);
      tone(180, 0.08, "square", 0.03);
    },
    whoosh: () => {
      makeNoise(ac(), 0.22, 0.03);
      tone(140, 0.2, "sine", 0.03);
    },
    mark: () => {
      tone(660, 0.07, "sine", 0.04);
    },
    wrong: () => {
      tone(196, 0.16, "sawtooth", 0.04);
      tone(147, 0.22, "square", 0.02, 0.05);
    },
    resolve: () => {
      tone(392, 0.18, "sine", 0.05);
      tone(494, 0.22, "sine", 0.04, 0.12);
      tone(587, 0.3, "sine", 0.04, 0.24);
      tone(784, 0.4, "triangle", 0.03, 0.38);
    },
    stop: () => {
      void ctx?.close();
      ctx = null;
    },
  };
}
